#ifndef _levels_
#define _levels_
/////////////////////////////////////////
// Mapping for Puzzle 1 (64)
// 0 = empty tile (for updating purposes)
// 1 = vacant tile
// 2 = tile 1(2)
// 3 = tile 2(4)
// 4 = tile 3(8)
// 5 = tile 4(16)
// 6 = tile 5(32)
// 7 = tile 6(64)
int Puzzle1Map[4][4] = {
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
};

#endif // !_levels_

