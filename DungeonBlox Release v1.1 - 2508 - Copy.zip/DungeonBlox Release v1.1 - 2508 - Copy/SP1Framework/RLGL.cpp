#include <Windows.h>
#include <iostream>
#include <ctime>
#include <fstream>
#include <string>
#include "RLGL.h"
#include "game.h"

using namespace std;

int RLGL_ID(int floors, int random);
Lights Red, Yellow, Green;
Game2 RLGL;
ifstream MapLayout;
GMAP Floor;
CStopWatch tlimit;
// SGameChar g_sChar;

void Puzzle2LoadLayout(int Layout, int Map[32][90])
//one function to get the randomised ID from the randomiser and load in the map
{
	switch (Layout)
	{
	case 11:
		MapLayout.open("RLGL Layouts\\Floor1_1.txt");
		break;
	case 12:
		MapLayout.open("RLGL Layouts\\Floor1_2.txt");
		break;
	case 13:
		MapLayout.open("RLGL Layouts\\Floor1_3.txt");
		break;
	case 14:
		MapLayout.open("RLGL Layouts\\Floor1_4.txt");
		break;
	case 21:
		MapLayout.open("RLGL Layouts\\Floor2_1a.txt");
		break;
	case 22:
		MapLayout.open("RLGL Layouts\\Floor2_1b.txt");
		break;
	case 23:
		MapLayout.open("RLGL Layouts\\Floor2_2a.txt");
		break;
	case 24:
		MapLayout.open("RLGL Layouts\\Floor2_2b.txt");
		break;
	case 25:
		MapLayout.open("RLGL Layouts\\Floor2_3a.txt");
		break;
	case 26:
		MapLayout.open("RLGL Layouts\\Floor2_3b.txt");
		break;
	case 27:
		MapLayout.open("RLGL Layouts\\Floor2_4a.txt");
		break;
	case 28:
		MapLayout.open("RLGL Layouts\\Floor2_4b.txt");
		break;
	case 31:
		MapLayout.open("RLGL Layouts\\Floor3_1a.txt");
		break;
	case 32:
		MapLayout.open("RLGL Layouts\\Floor3_1b.txt");
		break;
	case 33:
		MapLayout.open("RLGL Layouts\\Floor3_2a.txt");
		break;
	case 34:
		MapLayout.open("RLGL Layouts\\Floor3_2b.txt");
		break;
	case 35:
		MapLayout.open("RLGL Layouts\\Floor3_3a.txt");
		break;
	case 36:
		MapLayout.open("RLGL Layouts\\Floor3_3b.txt");
		break;
	case 37:
		MapLayout.open("RLGL Layouts\\Floor3_4a.txt");
		break;
	case 38:
		MapLayout.open("RLGL Layouts\\Floor3_4b.txt");
		break;
	}

	if (MapLayout.is_open())
	{
		for (int y = 0; y < 32; y++)
		{
			getline(MapLayout, RLGL.line);
			RLGL.line += '\n';

			for (int x = 0; x < 90; x++)
			{
				RLGL.Layout[y][x] = RLGL.line[x] - 48;

				if (RLGL.line[x] == '5')
					// locate the position of player spawn
				{
					//g_sChar.m_cLocation.X = x;
					RLGL.start.x = x;

					//g_sChar.m_cLocation.Y = y;
					RLGL.start.y = y;
				}
			}
		}
		MapLayout.close();
	}

	for (int x = 0; x < 90; x++) {
		for (int y = 0; y < 32; y++) {

			Map[y][x] = RLGL.Layout[y][x];

		}
	}

}

double YellowTiming(int floor)
//
{

	switch (floor)// the countdown for yellow light gets faster as the game progress to a new floor
	{
	case M_LEVEL1:
		Yellow.timing = YLight[0];
		break;
	case M_LEVEL2:
		Yellow.timing = YLight[1];
		break;
	case M_LEVEL3:
		Yellow.timing = YLight[2];
	}
	return Yellow.timing;
}

int RLGLstartx()
{
	return RLGL.start.x;
}

int RLGLstarty()
{
	return RLGL.start.y;
}

