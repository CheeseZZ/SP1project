#ifndef _RLGL_PUZZLE_H_
#define _RLGL_PUZZLE_H_
#pragma once

double YLight[3] = { 3.0, 2.0, 1.0 };

struct Location
{
	int x;
	int y;
};

extern struct Game2
{
	std::string line;
	int Layout[32][90] = { 0 , };
	double TimeLimit, Timer;
	int Lives = 3;
	bool Win = false;
	bool MoveRed = false;
	Location start, check, win;
	bool newGame = true;
};

struct Lights
{
	double timing;
	Location position[12];
};

#endif // _RLGL_H