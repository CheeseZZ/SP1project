#ifndef _PLAYER_STATS_
#define _PLAYER_STATS_

int options;
struct Inventory {
	bool lamp = false;
	//For Traps//
	bool ready = false;
	bool trigger = false;
	//For trap//
	int present = 0;
	int Bombs = 0;
	int clover = 0;
	int hourglass = 0;
};
struct Inventory Inv;;
struct Player {
	int health = 3;
	int money = 5;
	struct Inventory Inv;
};
COORD trap;
#endif // !_PLAYER_STATS_