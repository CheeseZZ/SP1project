#ifndef _GAME_H
#define _GAME_H

#include "Framework\timer.h"
#include <string>
extern CStopWatch g_swTimer;
extern bool g_bQuitGame;


// Enumeration to store the control keys that your game will have
enum EKEYS
{
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    K_SPACE,
	K_F1,
	K_INT,
	K_ONE,
	K_TWO,
	K_THREE,
	K_FOUR,
    K_COUNT
};

// Enumeration for the different screen states
enum EGAMESTATES
{
    S_SPLASHSCREEN,
	S_MENU,
	S_SUBMENU,
    S_GAME,
    S_COUNT,
	S_PAUSE,
	S_SHOP,
	S_PUZZLE,
	S_BOSS,
	S_CHEST,
	S_NEXTLEVEL,
	S_PUZZLE_PRACTICE,
	S_FINAL,
	S_FINALDEATH,
	S_WIN,
	S_ENDGAME,
	S_LOSE,
	S_TESTING
};

// Enumeration for different Menu choices
enum EMENU
{
	M_NEW,
	M_PRACTICE
};

// Enumeration for different levels
enum GMAP
{
	M_LEVEL1,
	M_LEVEL2,
	M_LEVEL3
};

// Enumeration for different Puzzles
enum GPUZZLES
{	
	P_EMPTY,
	P_TRIAL_N_ERROR,
	P_64,
	P_RED_LIGHT_GREEN_LIGHT,
	P_RIDDLES
};
// Enumeration for Riddler Question State
enum P_RIDDLER {
	R_QUESTION1,
	R_QUESTION2,
	R_QUESTION3,
	R_QUESTION4,
	R_QUESTION5,
	R_QUESTION6,
	R_FAIL,
	R_PASS
};
// Enumerations for Final Boss
// Enum for Boss Phases
enum BOSS {
	F_INTRO,
	F_LOSE,
	F_B_PHASE1,
	F_B_PHASE2,
	F_B_PHASE3,
	F_WIN
};
// Enum for Attack Phases of boss
enum ATTACK {
	A_NOTHING,
	A_0,
	A_1,
	A_2,
	A_3,
	A_4
};
// Enum for Updates to Attack Phases, Phases... of Boss
enum FINALUPDATES {
	U_NOTHING,
	U_0,
	U_1,
	U_2,
	U_3,
	U_4
};
// struct cycle variables for Attacks
struct AttackVariables {
	int cycle = 0;
	int UpdateCycle = 0;
};
// struct with other variables for Boss Stage
struct FINALVARIABLES {
	double CharBounceTime = 0;
	double UpdateBounceTime = 0;
	double CharacterUpdateBounceTime = 0;
	double SurvivalTime = 200;
	double FinalStartTime = 0;
	double LogicBounceTime = 0;
	double BossBounceTime = 0;
	int CharacterColour = 0xF4;
	int BossAttack = -1;
	int Dialogue = 0;
};
// struct with variables related to character during boss stage
struct CHARACTER {
	int health = 5;
	bool Hurt = false;
	bool HurtLoop = false;
};
// Enumeration for Shop Items
enum items
{
	Lamp,
	Heart,
	Present,
	Hourglass,
	Bombs,
	Clover,
	Exit,
	Count
};
// struct for the game character
struct SGameChar
{
    COORD m_cLocation;
    bool  m_bActive;
};
struct moveChar
{
	COORD m_cLocation2;
	bool m_bActive2;
};
struct Move4Char
{
	COORD m_cLocation4;
	bool m_bActive4;
};
struct Enemy4Char
{
	COORD m_cLocation5;
	bool m_bActive5;
};
struct EnemyVariables {
	COORD coor;
	int aEmptytiles[3][3] = { 0, };
	bool vacantTiles = false;
};
struct RLGLVARS {
	COORD spawn;
	bool spawned = false;
};

void init        ( void );      // initialize your variables, allocate memory, etc
void getInput    ( void );      // get input from player
void update      ( double dt ); // update the game and the state of the game
void render      ( void );      // renders the current state of the game to the console
void shutdown    ( void );      // do clean up, free memory

void splashScreenWait();						  // waits for time to pass in splash screen
void gameplay();								  // gameplay logic
void moveCharacter(int CurrentMap[10][30]);       // moves the character, collision detection, physics, etc
void processUserInput();						  // checks if you should change states or do something else with the game, e.g. pause, exit
void clearScreen();								  // clears the current screen and draw from scratch 
void renderSplashScreen();						  // renders the splash screen
void renderGame();								  // renders the game stuff
void renderMap(int CurrentMap[10][30]);           // renders the map to the buffer first
void renderCharacter();							  // renders the character into the buffer
void renderPauseScreen();						  // renders the pause screen
void renderMenu();								  // renders the pre-game Menu
void renderstats();								  // renders player statistics
void renderFramerate();							  // renders debug information, frame rate, elapsed time, etc
void renderToScreen();							  // dump the contents of the buffer to the screen, one frame worth of game
void saveFile();					           	// saves game into savefile
void loadFile();								  // loads savefile into game.
void chestRand();								  // Randomizes chest output
void chestRender();								  // Renders chest opening screen
void enemyAI(int CurrentMap[10][30], EnemyVariables g_eVars[20]);			  // function to allow enemy movement
//
void renderPracticeScreen();
void puzzlePractice();
void reset();

// Level Buffers
void nextLevelWait();
void renderNextLevel();

//Shop and Inventory
void updateShop();								//Update Shop
void renderShop();								//Render Shop
void renderInventory();	//render the inventory and items you have
void updateInventory(int CurrentMap[10][30]);    //Updates contents of Inventory and monitor item usage


// Puzzles functions 
void puzzleRandomize();		// Randomizes puzzles

// Trial and error puzzle
void movepuzzle0();
void movePuzzle0();
void puzzle0();				//renders the Trial and error puzzle
void PuzzleT1(int CurrentMap[10][30]);			//renders the Trial and error puzzle difficulty 1

// 64 (2048-style) puzzle
int Puzzle64(int keyPressed, int PuzzleMap[4][4]);			// main logic function for puzzle 64
void renderPuzzle1();					// Renders puzzle to screen
void updatePuzzle(int keyPressed, int PuzzleMap[4][4]);		// updates tile coordinates 
void randomTileGenerator(bool newGame, int PuzzleMap[4][4]); // generates new tiles
void puzzle1Move(int CurrentMap[10][30]);						// detects key presses and updates puzzle
void Puzzle1Reset();					// Resets puzzle

// Red light, green light
int RLGL_ID(int floors, int random);
void RLGLrandom();
double YellowTiming(int floor);
void Puzzle2(int CurrentMap[32][90]);
void Puzzle2LoadLayout(int Layout, int Map[32][90]);
void renderPuzzle2(int CurrentMap[32][90]);
void Puzzle2Timer();

// Riddler (BOSS) puzzle
void renderiddles();
void moveriddles();

// Loading of Map
void LoadLayout(int Map[10][30], GMAP mFloor);

// Puzzle 4 
void renderPuzzle4();
void Puzzle4Move();

// Functions for Boss
// mr Weng if you are reading this im sorry if its messy :') 
// didnt have much time to clean up especially into separate files cause i know
// the attacks especially should all be in separate files
void FinalRender();
void Final();

// Character-focused functions
void FinalCharacterMove();
void FinalDamageDetection();
void DamageUpdate();
void BossAI(); // "AI" for boss
void Finalupdates();

// Intro Dialogue functions
void FinalDialogueLogic();
void FinalDialogueRender();

void AttackUpdate(); // functions that deals with attack updates i.e. what attacks occur and the functions the attack is related to

// functions for first attack
void Attack0();
void Attack0Update();
void Attack0Finish();

// functions for second attack
void Attack1();
void Attack1Update();
void Attack1Finish();

// functions for third attack
void Attack2();
void Attack2Update();
void Attack2Finish();

// functions for fourth attack
void Attack3();
void Attack3Update();
void Attack3Finish();

// functions for fifth attack
void Attack4();
void Attack4Update();
void Attack4Finish();

// Extra Splashscreens functions
void renderFinalLoseScreen();
void renderLoseScreen();
void EndGameRender();
void EndGame();
#endif // _GAME_H