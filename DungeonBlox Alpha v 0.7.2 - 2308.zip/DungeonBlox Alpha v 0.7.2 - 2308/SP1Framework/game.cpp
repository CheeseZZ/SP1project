// This is the main file for the game logic and function
//
//
#include "game.h"
#include "Framework\console.h"
#include "levels.h"
#include "Random Logos and designs.h"
#include "Trial_And_Error.h"
#include "Rhythm.h"
#include "Player_Stats.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>
#include <string>
std::string Inventory;

double  g_dElapsedTime;
double g_dWaitTime;  // to Allow splashscreen to wait momentarily
double  g_dDeltaTime;
double g_dPuzzleTimer = 0.00;
bool    g_abKeyPressed[K_COUNT];
bool    g_abKeyPressed1[K_COUNT];

/////////////////////////////////////////////////////////////////////////
bool chestLoop = false;
int chestGold = 0;
// Game specific variables here
SGameChar   g_sChar;
moveChar g_pChar;
Move4Char g_bChar;
Enemy4Char g_eChar;
EnemyVariables g_eVars[10];
Player	Character;
EGAMESTATES g_eGameState	= S_SPLASHSCREEN;
EMENU		g_eMenuState	= M_NEW;
GPUZZLES	g_ePuzzleState  = P_EMPTY;
GMAP		g_eLevel		= M_LEVEL1;
double  g_dBounceTime; // this is to prevent key bouncing, so we won't trigger keypresses more than once
COORD P_FinalPosition;
bool p = false;
// Console object
Console g_Console(90, 35, "SP1 Framework");
bool newGame = true; // for puzzle 1 - 64
bool riddlerInitialized = false;
bool screenWait = true;
bool PuzzlePractice = false;
double LevelTime = 0.000;
double enemyMovementTime = 0.000;

//--------------------------------------------------------------
// Purpose  : Initialisation function
//            Initialize variables, allocate memory, load data from file, etc. 
//            This is called once before entering into your main loop
// Input    : void
// Output   : void
//--------------------------------------------------------------
void init( void )
{
	srand(time(0));
    // Set precision for floating point output
    g_dElapsedTime = 0.0;
    g_dBounceTime = 0.0;
	g_dElapsedTime2 = 0.0;

    // sets the initial state for the game
    g_eGameState = S_SPLASHSCREEN;

    g_sChar.m_cLocation.X = 2;
    g_sChar.m_cLocation.Y = 1;
    g_sChar.m_bActive = true;
	g_pChar.m_cLocation2.X = 37;
	g_pChar.m_cLocation2.Y = 12;
	g_pChar.m_bActive2 = true;
    // sets the width, height and the font name to use in the console
    g_Console.setConsoleFont(0, 16, L"Consolas");
}

//--------------------------------------------------------------
// Purpose  : Reset before exiting the program
//            Do your clean up of memory here
//            This is called once just before the game exits
// Input    : Void
// Output   : void
//--------------------------------------------------------------
void shutdown( void )
{
    // Reset to white text on black background
    colour(FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED);

    g_Console.clearBuffer();
}

//--------------------------------------------------------------
// Purpose  : Getting all the key press states
//            This function checks if any key had been pressed since the last time we checked
//            If a key is pressed, the value for that particular key will be true
//
//            Add more keys to the enum in game.h if you need to detect more keys
//            To get other VK key defines, right click on the VK define (e.g. VK_UP) and choose "Go To Definition" 
//            For Alphanumeric keys, the values are their ascii values (uppercase).
// Input    : Void
// Output   : void
//--------------------------------------------------------------
void getInput( void )
{    
    g_abKeyPressed[K_UP]     = isKeyPressed(VK_UP);
    g_abKeyPressed[K_DOWN]   = isKeyPressed(VK_DOWN);
    g_abKeyPressed[K_LEFT]   = isKeyPressed(VK_LEFT);
    g_abKeyPressed[K_RIGHT]  = isKeyPressed(VK_RIGHT);
    g_abKeyPressed[K_ESCAPE] = isKeyPressed(VK_ESCAPE);
    g_abKeyPressed[K_SPACE]  = isKeyPressed(VK_SPACE);
	g_abKeyPressed[K_F1]     = isKeyPressed(VK_F1);
	g_abKeyPressed[K_INT]	 = isKeyPressed('E');
	g_abKeyPressed[K_ONE] = isKeyPressed('1');
	g_abKeyPressed[K_TWO] = isKeyPressed('2');
	g_abKeyPressed[K_THREE] = isKeyPressed('3');
	g_abKeyPressed[K_FOUR] = isKeyPressed('4');
}

//--------------------------------------------------------------
// Purpose  : Update function
//            This is the update function
//            double dt - This is the amount of time in seconds since the previous call was made
//
//            Game logic should be done here.
//            Such as collision checks, determining the position of your game characters, status updates, etc
//            If there are any calls to write to the console here, then you are doing it wrong.
//
//            If your game has multiple states, you should determine the current state, and call the relevant function here.
//
// Input    : dt = deltatime
// Output   : void
//--------------------------------------------------------------
void update(double dt)
{
    // get the delta time
    g_dElapsedTime += dt;
    g_dDeltaTime = dt;

    switch (g_eGameState)
    {
		case S_MENU: processUserInput(); // game logic for menu screen
			break;
        case S_SPLASHSCREEN : splashScreenWait(); // game logic for the splash screen
            break;
        case S_GAME: gameplay(); // gameplay logic when we are in the game
            break;
		case S_PAUSE: processUserInput(); // game logic for pause screen
			break;
		case S_SHOP:
			break;
		case S_PUZZLE:
			g_dPuzzleTimer -= dt; // Timer for Puzzle
		switch (g_ePuzzleState) {
			case P_TRIAL_N_ERROR:
				movePuzzle0();
				break;
			case P_64:
				switch (g_eLevel) {
				case M_LEVEL1:
					puzzle1Move(aLevel1);
					break;
				case M_LEVEL2:
					puzzle1Move(aLevel2);
					break;
				case M_LEVEL3:
					puzzle1Move(aLevel3);
					break;
				}
				break;
		}
			break;
		case S_CHEST: chestRand();
			break;
		case S_BOSS: 
			switch (g_eLevel) {
			case M_LEVEL1: moveriddles();
				break;
			}
			break;
		case S_NEXTLEVEL: nextLevelWait();
			break;
		case S_PUZZLE_PRACTICE: puzzlePractice();
			break;
    }
}
//--------------------------------------------------------------
// Purpose  : Render function is to update the console screen
//            At this point, you should know exactly what to draw onto the screen.
//            Just draw it!
//            To get an idea of the values for colours, look at console.h and the URL listed there
// Input    : void
// Output   : void
//--------------------------------------------------------------
void render()
{
    clearScreen();      // clears the current screen and draw from scratch 
    switch (g_eGameState)
    {
		case S_MENU: renderMenu();
			break;
        case S_SPLASHSCREEN: renderSplashScreen();
            break;
		case S_GAME: renderGame();
            break;
		case S_PAUSE: renderPauseScreen();
			break;
		case S_SHOP: renderShop();
			break;
		case S_PUZZLE:switch (g_ePuzzleState) {
			case P_TRIAL_N_ERROR:
				puzzle0();
				break;
			case P_64:
				if (newGame) {
					Puzzle1Reset();
					randomTileGenerator(newGame, Puzzle1Map);
					newGame = false;
				}
				renderPuzzle1();
				break;
		}
			break;
		case S_CHEST: chestRender();
			break;
		case S_BOSS: 
			switch (g_eLevel) {
			case M_LEVEL1: renderiddles();
				break;
			}
			break;
		case S_NEXTLEVEL: renderNextLevel();
			break;
		case S_PUZZLE_PRACTICE: renderPracticeScreen();
			break;
    }
    renderFramerate();  // renders debug information, frame rate, elapsed time, etc
    renderToScreen();   // dump the contents of the buffer to the screen, one frame worth of game
}

void puzzlePractice() { // movement of Cursor during puzzle practice screen as well as adjusting states to allow player to practice puzzles
	PuzzlePractice = true;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	if (PuzzlePractice) {
		bool SomethingHappened = false;
		g_sChar.m_cLocation.X = 7;
		if (g_sChar.m_cLocation.Y > 9) 
			g_sChar.m_cLocation.Y = 9;
		if (g_sChar.m_cLocation.Y < 3)
			g_sChar.m_cLocation.Y = 3;
		if (g_abKeyPressed[K_DOWN]) {
			g_sChar.m_cLocation.Y += 2;
			SomethingHappened = true;
		}
		if (g_abKeyPressed[K_UP]) {
			g_sChar.m_cLocation.Y -= 2;
			SomethingHappened = true;
		}
		if (g_abKeyPressed[K_SPACE]) {
			g_eGameState = S_PUZZLE;
			switch ((g_sChar.m_cLocation.Y - 1) / 2) {
			case 1:
				g_ePuzzleState = P_TRIAL_N_ERROR;
				break;
			case 2:
				g_ePuzzleState = P_64;
				break;
			case 3:
				g_ePuzzleState = P_RED_LIGHT_GREEN_LIGHT;
				break;
			case 4:
				PuzzlePractice = false;
				g_eGameState = S_MENU;
				break;
			}
		}
		if (SomethingHappened)
			g_dBounceTime = g_dElapsedTime + 0.200;
	}
}
void renderPracticeScreen() {
	COORD c;
	g_Console.writeToBuffer(g_sChar.m_cLocation, ">", 0x0F);
	c.X = 8;
	c.Y = 3;
	g_Console.writeToBuffer(c, "Trial and Error", 0x0F);
	c.Y += 2;
	g_Console.writeToBuffer(c, "64", 0x0F);
	c.Y += 2;
	g_Console.writeToBuffer(c, "Red Light, Green Light", 0x0F);
	c.Y += 2;
	g_Console.writeToBuffer(c, "Return to Main Menu", 0x0F);
	switch ((g_sChar.m_cLocation.Y - 1) / 2) {
	case 1:
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	}
}


void splashScreenWait()    // waits for time to pass in splash screen
{
	if (g_dElapsedTime > 5.0)
		g_eGameState = S_MENU;
}
void nextLevelWait() { 
	if (screenWait) {
		LevelTime = g_dElapsedTime;
		g_dBounceTime = g_dElapsedTime + 3.000;
		screenWait = false;
	}
	if (g_dBounceTime < g_dElapsedTime && !screenWait) {
		g_eGameState = S_GAME;
		switch (g_eLevel) {
		case M_LEVEL1:
			g_sChar.m_cLocation.X = 2;
			g_sChar.m_cLocation.Y = 19;
			g_eLevel = M_LEVEL2;
			break;
		case M_LEVEL2:
			g_eLevel = M_LEVEL3;
			break;
		case M_LEVEL3:
			g_eGameState = S_ENDGAME;
			break;
		}
		screenWait = true;
		return;
	}
}
void renderNextLevel() { // Renders Level buffer screen
	for (int y = 0; y < 7; y++) {
		for (int x = 0; x < 71; x++) {
			switch (Next_level[y][x]) {
			case 0: g_Console.writeToBuffer(x + 5, y + 5, " ", 0x00);
				break;
			case 1: g_Console.writeToBuffer(x + 5, y + 5, " ", 0xC0);
				break;
			}
		}
	}
	std::ostringstream ss;
	ss.str("");
	ss << "Health Remainding: ";
	for (int x = 0; x < Character.health; x++) {
		ss << (char)3;
	}
	g_Console.writeToBuffer(10, 13, ss.str(), 0x0F);
	ss.str("");
	ss << "Time Taken : " << LevelTime << "seconds";
	g_Console.writeToBuffer(10, 15, ss.str(), 0x0F);
}

void gameplay()            // gameplay logic
{
	processUserInput(); // checks if you should change states or do something else with the game, e.g. pause, exit
	switch (g_eLevel) {
	case M_LEVEL1:
		moveCharacter(aLevel1); // moves the character, collision detection, physics, etc
		enemyAI(aLevel1);  
		break;
	case M_LEVEL2:
		moveCharacter(aLevel2);
		enemyAI(aLevel2);
		break;
	case M_LEVEL3:
		moveCharacter(aLevel3);
		enemyAI(aLevel3);
		break;
	}
                        // sound can be played here too.
}

void moveCharacter(int CurrentMap[10][30])
{
    bool bSomethingHappened = false;
    if (g_dBounceTime > g_dElapsedTime)
        return;
    // Updating the location of the character based on the key press
    // providing a beep sound whenver we shift the character
	if (g_abKeyPressed[K_UP] && CurrentMap[player.Y - 1][player.X] == 0 && player.Y > 0 && g_eGameState == S_GAME)
    {
        Beep(1440, 30);
        g_sChar.m_cLocation.Y -=2;
        bSomethingHappened = true;
		
    }
    if (g_abKeyPressed[K_LEFT] && CurrentMap[player.Y][player.X-1] == 0 && player.X > 0 && !g_abKeyPressed[K_DOWN]&&!g_abKeyPressed[K_UP] && g_eGameState == S_GAME)
    {
        Beep(1440, 30);
        g_sChar.m_cLocation.X -=2;
        bSomethingHappened = true;
    }
    if (g_abKeyPressed[K_DOWN] && CurrentMap[player.Y + 1][player.X] == 0&&player.Y<9 && g_eGameState == S_GAME)
    {
        Beep(1440, 30);
        g_sChar.m_cLocation.Y +=2 ;
        bSomethingHappened = true;
    }
    if (g_abKeyPressed[K_RIGHT] && CurrentMap[player.Y][player.X + 1] == 0 && player.X < 29 && !g_abKeyPressed[K_DOWN]&& !g_abKeyPressed[K_UP] && g_eGameState == S_GAME)
    {
        Beep(1440, 30);
        g_sChar.m_cLocation.X += 2;
        bSomethingHappened = true;
    }
	if (g_abKeyPressed[K_INT] && (CurrentMap[player.Y+1][player.X] == 4 || CurrentMap[player.Y - 1][player.X] == 4 || CurrentMap[player.Y][player.X+1] == 4 || CurrentMap[player.Y][player.X -1] == 4))
	{
		g_eGameState = S_SHOP;
	}
	if (g_abKeyPressed[K_INT] && (CurrentMap[player.Y + 1][player.X] == 2 || CurrentMap[player.Y - 1][player.X] == 2 || CurrentMap[player.Y][player.X + 1] == 2 || CurrentMap[player.Y][player.X - 1] == 2))
	{
		puzzleRandomize();
		g_dPuzzleTimer = 90.0; // resets timer to 90 seconds for each puzzle
		g_eGameState = S_PUZZLE;
	}
	if (g_abKeyPressed[K_INT] && (CurrentMap[player.Y + 1][player.X] == 5 || CurrentMap[player.Y - 1][player.X] == 5 || CurrentMap[player.Y][player.X + 1] == 5 || CurrentMap[player.Y][player.X - 1] == 5))
	{
		g_eGameState = S_BOSS;
		if (g_eLevel == M_LEVEL2)
		{
			g_dPuzzleTimer = 60.0; // resets timer to 60 seconds for floor boss 2
			PlaySound(TEXT("Audio2.wav"), NULL, SND_ASYNC);
		}
	}
	if (g_abKeyPressed[K_INT] && (CurrentMap[player.Y + 1][player.X] == 3 || CurrentMap[player.Y - 1][player.X] == 3 || CurrentMap[player.Y][player.X + 1] == 3 || CurrentMap[player.Y][player.X - 1] == 3))
	{
		if (CurrentMap[player.Y + 1][player.X] == 3) {
			CurrentMap[player.Y + 1][player.X] = 0;
		}
		if (CurrentMap[player.Y - 1][player.X] == 3) {
			CurrentMap[player.Y - 1][player.X] = 0;
		}
		if (CurrentMap[player.Y][player.X + 1] == 3) {
			CurrentMap[player.Y][player.X + 1] = 0;
		}
		if (CurrentMap[player.Y][player.X - 1] == 3) {
			CurrentMap[player.Y][player.X - 1] = 0;
		}
		g_eGameState = S_CHEST;
	}
    if (g_abKeyPressed[K_SPACE] && g_eGameState == S_GAME)
    {
        g_sChar.m_bActive = !g_sChar.m_bActive;
        bSomethingHappened = true;
    }
    if (bSomethingHappened)
    {
		P_FinalPosition = g_sChar.m_cLocation;
        // set the bounce time to some time in the future to prevent accidental triggers
        g_dBounceTime = g_dElapsedTime + 0.125; // 125ms should be enough
    }
}
void processUserInput()
{
	bool bSomethingHappened = false;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	// Changes menu state accordingly
	if (g_abKeyPressed[K_DOWN] && g_eGameState == S_MENU) // press down for continue game state
		g_eMenuState = M_PRACTICE;
	if (g_abKeyPressed[K_UP] && g_eGameState == S_MENU) // press up for New game state
		g_eMenuState = M_NEW;
	// Load or start new game according to state
	if (g_abKeyPressed[K_SPACE] && g_eGameState == S_MENU) {
		switch (g_eMenuState) {
		case M_NEW: 
			g_sChar.m_cLocation.Y = 1;
			g_sChar.m_cLocation.X = 60;
			g_eGameState = S_GAME;
			break;
		case M_PRACTICE: PuzzlePractice = true;
			g_eGameState = S_PUZZLE_PRACTICE;
			break;
		}
		bSomethingHappened = true;
	}
	// pauses/unpauses the game if player hits the F1 key
	if (g_abKeyPressed[K_F1]&& g_eGameState == S_PAUSE)
		g_eGameState = S_GAME;
	else if (g_abKeyPressed[K_F1])
		g_eGameState = S_PAUSE;
    // quits the game if player hits the escape key
    else if (g_abKeyPressed[K_ESCAPE])
        g_bQuitGame = true;
	
	if (bSomethingHappened)
	{
		// set the bounce time to some time in the future to prevent accidental triggers
		g_dBounceTime = g_dElapsedTime + 0.25; // 250ms should be enough
	}
}

void clearScreen()
{
    // Clears the buffer with this colour attribute
    g_Console.clearBuffer(0x1F);
}

void renderSplashScreen()  // renders the splash screen
{
    COORD c = g_Console.getConsoleSize();
    c.Y /= 3;
    c.X = c.X / 2 - 9;
    g_Console.writeToBuffer(c, "Use Arrow Keys to move", 0x03);
    c.Y += 1;
    c.X = g_Console.getConsoleSize().X / 2 - 20;
    g_Console.writeToBuffer(c, "Press <Space> to select items or engage during puzzles", 0x09);
    c.Y += 1;
    c.X = g_Console.getConsoleSize().X / 2 - 9;
    g_Console.writeToBuffer(c, "Press <E> to interact with the Map", 0x09);
}

void renderGame()
{
	renderstats();		// renders statistics to screen
	switch (g_eLevel) {
	case M_LEVEL1:
		renderMap(aLevel1);        // renders the map to the buffer first
		break;
	case M_LEVEL2:
		renderMap(aLevel2);
		break;
	case M_LEVEL3:
		renderMap(aLevel3);
		break;
	}
    renderCharacter();  // renders the character into the buffer
}

void renderMap(int CurrentMap[10][30])
{
	int LightRadius = 1 + Inv.lamp;
    // Set up sample colours, and output shadings
    const WORD colors[] = {
        0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
        0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
    };
    COORD c;
	player.X = (g_sChar.m_cLocation.X / 2) - 1;
	player.Y = (g_sChar.m_cLocation.Y / 2);
	c.Y = 1;
	// Render frames for game, inventory, etc.
	for (int y = 0; y < 10; y++, c.Y+= 2) {
		c.X = 2;
		for (int x = 0; x < 30; x++, c.X+= 2) {
			// for loop to scale map size by 2
			for (int i = 0; i < 4; i++) {
				// switch to ensure smooth scaling
				switch (i) {
				case 0:
					break;
				case 1:
					c.X++;
					break;
				case 2:
					c.Y++;
					break;
				case 3:
					c.X--;
					break;
				}
				g_Console.writeToBuffer(c, " ", 0x00);
				if (((x >= player.X - LightRadius) && (x <= player.X + LightRadius)) && ((y >= player.Y - LightRadius) && (y <= player.Y + LightRadius))) {
					switch (CurrentMap[y][x]) {
					case 0: // empty tile
						g_Console.writeToBuffer(c, " ", 0xFF);
						break;
					case 1: // wall
						g_Console.writeToBuffer(c, " ", 0x00);
						break;
					case 2: // enemy
						switch (i) {
						case 0:
							g_Console.writeToBuffer(c, "C", 0xE0);
							break;
						case 1:
							g_Console.writeToBuffer(c, "|", 0xE0);
							break;
						case 2:
							g_Console.writeToBuffer(c, "|", 0xE0);
							break;
						case 3:
							g_Console.writeToBuffer(c, "C", 0xE0);
							break;
						}
						break;
					case 3: // chests
						g_Console.writeToBuffer(c, " ", 0xAA);
						break;
					case 4: // shop
						g_Console.writeToBuffer(c, " ", 0xBB);
						break;
					case 5: // final
						g_Console.writeToBuffer(c, " ", 0xD0);
						break;
					default:
						g_Console.writeToBuffer(c, " ", 0x00);
						break;
					}
				}
			}
			c.Y--;
		}
	}
	renderInventory();
}

void renderCharacter()
{
	// value of character
	char charImage = 2;
	// Draw the location of the character
	WORD charColor = 0xF7;
	if (g_sChar.m_bActive)
	{
		charColor = 0xF9;
	}

	// loop to scale the character size by 2
	for (int i = 0; i < 4; i++) {
		switch (i) {
		case 0:
			break;
		case 1:
			g_sChar.m_cLocation.X++;
			charImage = 191;
			break;
		case 2:
			g_sChar.m_cLocation.Y++;
			charImage = 217;
			break;
		case 3:
			g_sChar.m_cLocation.X--;
			charImage = 192;
			break;
		}
		g_Console.writeToBuffer(g_sChar.m_cLocation, charImage, charColor);
	}
	g_sChar.m_cLocation.Y--;
}

void renderFramerate()
{
    COORD c;
    // displays the framerate
    std::ostringstream ss;
    ss << std::fixed << std::setprecision(3);
    ss << 1.0 / g_dDeltaTime << "fps";
    c.X = g_Console.getConsoleSize().X - 9;
    c.Y = 0;
    g_Console.writeToBuffer(c, ss.str());

    // displays the elapsed time
	if (g_eGameState == S_PUZZLE) {
		ss.str("");
		ss << g_dPuzzleTimer << "secs remainding";
		g_Console.writeToBuffer(0, 0, ss.str(), 0x0F);
	}
	else {
		ss.str("");
		ss << g_dElapsedTime << "secs";
		c.X = 0;
		c.Y = 0;
		g_Console.writeToBuffer(c, ss.str(), 0x59);
	}
}
void renderToScreen()
{
    // Writes the buffer to the console, hence you will see what you have written
    g_Console.flushBufferToConsole();
}
void renderPauseScreen() // Renders pause screen
{
	COORD c = g_Console.getConsoleSize();
	c.Y = 4;
	c.X = 6;
	g_Console.writeToBuffer(c, "Paused", 0x01);
	c.Y++;
	c.X = 4;
	g_Console.writeToBuffer(c, "Press F1 to contiue", 0x03);
}
void renderMenu() // Renders Menu
{
	COORD c = g_Console.getConsoleSize();
	c.Y = 4;
	c.X = 6;
	g_Console.writeToBuffer(c, "Welcome to Dungeon Escape", 0x0A);
	c.Y += 2;
	g_Console.writeToBuffer(c, "Start Game", 0x0A);
	c.Y++;
	g_Console.writeToBuffer(c, "Practice Puzzles", 0x0A);
	c.Y = 6 + g_eMenuState;
	c.X = 5;
	g_Console.writeToBuffer(c, ">", 0x0A);
}
void renderstats()
{	//display health
	COORD c;
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);
	ss.str("");
	ss << "Life: ";
	for (int i = 0;i < Character.health ;i++)
	{
		ss << (char)3;
	}
	c.X = 2;
	c.Y = 22;
	g_Console.writeToBuffer(c, ss.str(), 0x59);

	//display cash
	ss.str("");
	ss << "Cash: " << Character.money;
	c.X = 2;
	c.Y = 23;
	g_Console.writeToBuffer(c, ss.str(), 0x59);

}

void enemyAI(int CurrentMap[10][30]) {
	if (enemyMovementTime > g_dElapsedTime)
		return;
	// find location of enemies
	int i = 0;
	for (int y = 0; y < 10; y++) {
		for (int x = 0; x < 30; x++) {
			if (CurrentMap[y][x] == 2) {
				g_eVars[i].coor.Y = y;
				g_eVars[i].coor.X = x;
				i++;
			}
		}
	}
	for (int i = 0; i < 8;i++) { // for loop to move enemies one by one
		int Tries = 0; // Failsafe to ensure loop does not run forever
		COORD tile;
		do { // do randoms to find any empty tile within 1 tile radius of enemy
			tile.Y = (rand() % 3) - 1;
			tile.X = (rand() % 3) - 1;
			Tries++;
			if ((0 > (g_eVars[i].coor.Y + tile.Y)) || (10 < (g_eVars[i].coor.Y + tile.Y)) || (0 > (g_eVars[i].coor.X + tile.X)) || (30 < (g_eVars[i].coor.X + tile.X))) {
				continue; // if empty tile detected is out of the map redo random
			}
			else if (CurrentMap[g_eVars[i].coor.Y + tile.Y][g_eVars[i].coor.X + tile.X] == 0 || Tries == 20)
				break; // if empty tile is detected and movable breaks loop
		} while (1);
		if (Tries == 20)
			continue;
		else {
			CurrentMap[g_eVars[i].coor.Y + tile.Y][g_eVars[i].coor.X + tile.X] = 2; // sets empty tile found to be new location of enemy
			CurrentMap[g_eVars[i].coor.Y][g_eVars[i].coor.X] = 0;
		}
	}
	enemyMovementTime = g_dElapsedTime + 2.250; // all enemies move every 2.25 seconds
}
////////////////////////////////////////////////////
// Chest Randomizer
////////////////////////////////////////////////////

void chestRand() {
	if (g_dBounceTime > g_dElapsedTime)
		return;
	else if (chestLoop) {
		chestGold = rand() % 4 + 1;
		chestLoop = false;
		Character.money += chestGold;
		g_eGameState = S_GAME;
	}

	if (g_eGameState == S_CHEST && !chestLoop) {
		chestLoop = true;
		g_dBounceTime = g_dElapsedTime + 2.0;
	}
}
void chestRender() {
	COORD c;
	c.Y = g_Console.getConsoleSize().Y / 2;
	c.X = g_Console.getConsoleSize().X / 2;
	std::ostringstream ss;
	ss.str("");
	ss << "Gold found : " << chestGold;
	g_Console.writeToBuffer(c, ss.str());
}
////////////////////////////////////////////////////
// Anything related to the puzzles go below here
////////////////////////////////////////////////////

// Puzzle Randomizer
void puzzleRandomize() {
	srand(g_dElapsedTime);
	int x = rand() % 2;
	//x = 0; // testing purposes
	switch (g_eLevel) {
	case M_LEVEL1:
		switch (x) {
		case 0:
			g_ePuzzleState = P_TRIAL_N_ERROR;
			break;
		case 1:
			g_ePuzzleState = P_64;
			break;
		case 2:
			g_ePuzzleState = P_RED_LIGHT_GREEN_LIGHT;
			break;
		}
		break;
	case M_LEVEL2:
		break;
	case M_LEVEL3:
		break;
	}
}
//////////////////////////////////
// Puzzle 0 - Trial and Error
// Done by Dave Philipus Wijaya
//////////////////////////////////
void puzzle0()
{
	COORD c = g_Console.getConsoleSize();
	c.Y = 10;
	c.X = 25;
	g_Console.writeToBuffer(c, "Find the correct number and order", 0x03);
	c.Y = 18;
	c.X = 13;
	g_Console.writeToBuffer(c, "Number of tries left:", 0x03);
	c.X = 35;
	g_Console.writeToBuffer(c, tries, 0x03);
	c.Y = 12;
	c.X = 37;
	g_Console.writeToBuffer(c, a, 0x03);
	c.X = 39;
	g_Console.writeToBuffer(c, b, 0x03);
	c.X = 41;
	g_Console.writeToBuffer(c, d, 0x03);
	c.X = 43;
	g_Console.writeToBuffer(c, e, 0x03);
	switch (g_eLevel) {
	case M_LEVEL1:
		PuzzleT1(aLevel1);
		break;
	case M_LEVEL2:
		PuzzleT1(aLevel2);
		break;
	case M_LEVEL3:
		PuzzleT1(aLevel3);
		break;
	}
/*	if (difficulty == 2 || difficulty == 3)
	{
		c.X = 45;
		g_Console.writeToBuffer(c, f, 0x03);
		if (difficulty == 2)
		{
			PuzzleT2();
		}
	}
	if (difficulty == 3)
	{
		c.X = 47;
		g_Console.writeToBuffer(c, g, 0x03);
		PuzzleT3();
	}*/
	c.Y = 14;
	c.X = 25;
	g_Console.writeToBuffer(c, "Correct:", 0x03);
	if (a5)
	{
		c.X = 37;
		g_Console.writeToBuffer(c, Trial1, 0x03);
	}
	if (a2)
	{
		c.X = 39;
		g_Console.writeToBuffer(c, Trial2, 0x03);
	}
	if (a3)
	{
		c.X = 41;
		g_Console.writeToBuffer(c, Trial3, 0x03);
	}
	if (a4)
	{
		c.X = 43;
		g_Console.writeToBuffer(c, Trial4, 0x03);
	}
	if (a6)
	{
		c.X = 45;
		g_Console.writeToBuffer(c, Trial5, 0x03);
	}
	if (a7)
	{
		c.X = 47;
		g_Console.writeToBuffer(c, Trial6, 0x03);
	}
	c.Y = 16;
	c.X = 16;
	g_Console.writeToBuffer(c, "Partially correct:", 0x03);
	if (pc1)
	{
		c.X = 37;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	if (pc2)
	{
		c.X = 39;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	if (pc3)
	{
		c.X = 41;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	if (pc4)
	{
		c.X = 43;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	if (pc5)
	{
		c.X = 45;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	if (pc6)
	{
		c.X = 47;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	movepuzzle0();
	movePuzzle0();
}

void movepuzzle0() //originally move()
{
	WORD charColor = 0x0C;
	if (g_sChar.m_bActive)
	{
		charColor = 0x0A;
	}
	if (g_pChar.m_cLocation2.X == 37)
		g_Console.writeToBuffer(g_pChar.m_cLocation2, a, charColor);
	if (g_pChar.m_cLocation2.X == 39)
		g_Console.writeToBuffer(g_pChar.m_cLocation2, b, charColor);
	if (g_pChar.m_cLocation2.X == 41)
		g_Console.writeToBuffer(g_pChar.m_cLocation2, d, charColor);
	if (g_pChar.m_cLocation2.X == 43)
		g_Console.writeToBuffer(g_pChar.m_cLocation2, e, charColor);
	if (g_pChar.m_cLocation2.X == 45)
		g_Console.writeToBuffer(g_pChar.m_cLocation2, f, charColor);
	if (g_pChar.m_cLocation2.X == 47)
		g_Console.writeToBuffer(g_pChar.m_cLocation2, g, charColor);
}
void movePuzzle0()
{
	bool bSomethingHappened = false;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	if (g_ePuzzleState==P_TRIAL_N_ERROR)
	{
			if (g_abKeyPressed[K_RIGHT] && g_pChar.m_cLocation2.X < 43)
			{
				g_pChar.m_cLocation2.X += 2;
				bSomethingHappened = true;
			}
		/*if (difficulty == 2)
		{
			if (g_abKeyPressed[K_RIGHT] && g_pChar.m_cLocation2.X < 45)
			{
				g_pChar.m_cLocation2.X += 2;
				bSomethingHappened = true;
			}
		}
		if (difficulty == 3)
		{
			if (g_abKeyPressed[K_RIGHT] && g_pChar.m_cLocation2.X < 47)
			{
				g_pChar.m_cLocation2.X += 2;
				bSomethingHappened = true;
			}
		}*/
		if (g_abKeyPressed[K_LEFT] && g_pChar.m_cLocation2.X > 37)
		{
			g_pChar.m_cLocation2.X -= 2;
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_UP])
		{
			if (g_pChar.m_cLocation2.X == 37 && a < '9')
			{
				a++;
			}
			if (g_pChar.m_cLocation2.X == 39 && b < '9')
			{
				b++;
			}
			if (g_pChar.m_cLocation2.X == 41 && d < '9')
			{
				d++;
			}
			if (g_pChar.m_cLocation2.X == 43 && e < '9')
			{
				e++;
			}
			if (g_pChar.m_cLocation2.X == 45 && f < '9')
			{
				f++;
			}
			if (g_pChar.m_cLocation2.X == 47 && g < '9')
			{
				g++;
			}
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_DOWN])
		{
			if (g_pChar.m_cLocation2.X == 37 && a > '0')
			{
				a--;
			}
			if (g_pChar.m_cLocation2.X == 39 && b > '0')
			{
				b--;
			}
			if (g_pChar.m_cLocation2.X == 41 && d > '0')
			{
				d--;
			}
			if (g_pChar.m_cLocation2.X == 43 && e > '0')
			{
				e--;
			}
			/*if (g_pChar.m_cLocation2.X == 45 && f > '0')
			{
				f--;
			}
			if (g_pChar.m_cLocation2.X == 47 && g > '0')
			{
				g--;
			}*/
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_SPACE])
		{
			p = true;
			bSomethingHappened = true;
			tries--;
			pc1 = false; pc2 = false; pc3 = false; pc4 = false; pc5 = false; pc6 = false;
		}
		if (bSomethingHappened)
		{
			// set the bounce time to some time in the future to prevent accidental triggers
			g_dBounceTime = g_dElapsedTime + 0.125; // 125ms should be enough
		}
	}
}
void PuzzleT1(int CurrentMap[10][30])
{
	if (edited)
	{
		srand(time(NULL));
		Trial1 = rand() % 10 + 48;
		Trial2 = rand() % 10 + 48;
		Trial3 = rand() % 10 + 48;
		Trial4 = rand() % 10 + 48;
		edited = false;
	}
	COORD c = g_Console.getConsoleSize();
	if (p)
	{
		if (a == Trial1)
		{
			a5 = true;
		}
		if (b == Trial2)
		{
			a2 = true;
		}
		if (d == Trial3)
		{
			a3 = true;
		}
		if (e == Trial4)
		{
			a4 = true;
		}
	}
	if (a == Trial1 && b == Trial2 && d == Trial3 && e == Trial4 && g_abKeyPressed[K_SPACE])
	{
		if (PuzzlePractice)
			g_eGameState = S_PUZZLE_PRACTICE;
		else {
			g_eGameState = S_GAME;
			if (CurrentMap[player.Y + 1][player.X] == 2)
			{
				CurrentMap[player.Y + 1][player.X] = 0;
			}
			else if (CurrentMap[player.Y - 1][player.X] == 2)
			{
				CurrentMap[player.Y - 1][player.X] = 0;
			}
			else if (CurrentMap[player.Y][player.X + 1] == 2)
			{
				CurrentMap[player.Y][player.X + 1] = 0;
			}
			else if (CurrentMap[player.Y][player.X - 1] == 2)
			{
				CurrentMap[player.Y][player.X - 1] = 0;
			}
			Character.money++;
		}
			a5 = false; a2 = false; a3 = false; a4 = false;
			pc1 = false; pc2 = false; pc3 = false; pc4 = false;
			enemy = false; edited = true;
			tries = 57;
			a = 48; b = 48; d = 48; e = 48;
	}
	if (p)
	{
		if (a == Trial2 || a == Trial3 || a == Trial4)
		{
			pc1 = true;
		}
		if (b == Trial1 || b == Trial3 || b == Trial4)
		{
			pc2 = true;
		}
		if (d == Trial1 || d == Trial2 || d == Trial4)
		{
			pc3 = true;
		}
		if (e == Trial1 || e == Trial2 || e == Trial3)
		{
			pc4 = true;
		}
		p = false;
	}
	if (tries == 48)
	{
		if (PuzzlePractice)
			g_eGameState = S_PUZZLE_PRACTICE;
		else {

			g_eGameState = S_GAME;
			if (CurrentMap[player.Y + 1][player.X] == 2 && CurrentMap[player.Y - 1][player.X] == 0)
			{
				g_sChar.m_cLocation.Y -= 2;
			}
			if (CurrentMap[player.Y - 1][player.X] == 2 && CurrentMap[player.Y + 1][player.X] == 0)
			{
				g_sChar.m_cLocation.Y += 2;
			}
			if (CurrentMap[player.Y][player.X + 1] == 2 && CurrentMap[player.Y][player.X - 1] == 0)
			{
				g_sChar.m_cLocation.X -= 2;
			}
			if (CurrentMap[player.Y][player.X - 1] == 2 && CurrentMap[player.Y][player.X + 1] == 0)
			{
				g_sChar.m_cLocation.X += 2;
			}
			Character.health -= 1;
		}
			a5 = false; a2 = false; a3 = false; a4 = false;
			pc1 = false; pc2 = false; pc3 = false; pc4 = false;
			enemy = false; edited = true;
			tries = 57;
			a = 48; b = 48; d = 48; e = 48;
	}
}
/*void PuzzleT2()
{
	if (edited)
	{
		srand(time(NULL));
		Trial1 = rand() % 10 + 48;
		Trial2 = rand() % 10 + 48;
		Trial3 = rand() % 10 + 48;
		Trial4 = rand() % 10 + 48;
		Trial5 = rand() % 10 + 48;
		edited = false;
	}
	COORD c = g_Console.getConsoleSize();
	if (p)
	{
		if (a == Trial1)
		{
			a5 = true;
		}
		if (b == Trial2)
		{
			a2 = true;
		}
		if (d == Trial3)
		{
			a3 = true;
		}
		if (e == Trial4)
		{
			a4 = true;
		}
		if (f == Trial5)
		{
			a6 = true;
		}
	}
	if (a == Trial1 && b == Trial2 && d == Trial3 && e == Trial4 && f == Trial5 && g_abKeyPressed[K_SPACE])
	{
		g_eGameState = S_GAME;
		if (aLevel1[player.Y + 1][player.X] == 2)
		{
			aLevel1[player.Y + 1][player.X] = 0;
		}
		else if (aLevel1[player.Y - 1][player.X] == 2)
		{
			aLevel1[player.Y - 1][player.X] = 0;
		}
		else if (aLevel1[player.Y][player.X + 1] == 2)
		{
			aLevel1[player.Y][player.X + 1] = 0;
		}
		else if (aLevel1[player.Y][player.X - 1] == 2)
		{
			aLevel1[player.Y][player.X - 1] = 0;
		}
		a5 = false; a2 = false; a3 = false; a4 = false; a6 = false;
		pc1 = false; pc2 = false; pc3 = false; pc4 = false; pc5 = false; g_pChar.m_cLocation2.X = 37;
		enemy = false; edited = true;
		tries = 57;
		a = 48; b = 48; d = 48; e = 48; f = 48;
	}
	if (p)
	{
		if (a == Trial2 || a == Trial3 || a == Trial4 || d == Trial5)
		{
			pc1 = true;
		}
		if (b == Trial1 || b == Trial3 || b == Trial4 || d == Trial5)
		{
			pc2 = true;
		}
		if (d == Trial1 || d == Trial2 || d == Trial4 || d == Trial5)
		{
			pc3 = true;
		}
		if (e == Trial1 || e == Trial2 || e == Trial3 || e == Trial5)
		{
			pc4 = true;
		}
		if (f == Trial1 || f == Trial2 || f == Trial3 || f == Trial4)
		{
			pc5 = true;
		}
		p = false;
	}
	if (tries == 48)
	{
		g_eGameState = S_GAME;
		if (aLevel1[player.Y + 1][player.X] == 2 && aLevel1[player.Y - 1][player.X] == 0)
		{
			g_sChar.m_cLocation.Y -= 2;
		}
		if (aLevel1[player.Y - 1][player.X] == 2 && aLevel1[player.Y + 1][player.X] == 0)
		{
			g_sChar.m_cLocation.Y += 2;
		}
		if (aLevel1[player.Y][player.X + 1] == 2 && aLevel1[player.Y][player.X - 1] == 0)
		{
			g_sChar.m_cLocation.X -= 2;
		}
		if (aLevel1[player.Y][player.X - 1] == 2 && aLevel1[player.Y][player.X + 1] == 0)
		{
			g_sChar.m_cLocation.X += 2;
		}
		a5 = false; a2 = false; a3 = false; a4 = false; a6 = false;
		pc1 = false; pc2 = false; pc3 = false; pc4 = false; pc5 = false; g_pChar.m_cLocation2.X = 37;
		enemy = false; edited = true;
		tries = 57;
		a = 48; b = 48; d = 48; e = 48; f = 48;
		Character.health -= 1;
	}
}
void PuzzleT3()
{
	if (edited)
	{
		srand(time(NULL));
		Trial1 = rand() % 10 + 48;
		Trial2 = rand() % 10 + 48;
		Trial3 = rand() % 10 + 48;
		Trial4 = rand() % 10 + 48;
		Trial5 = rand() % 10 + 48;
		Trial6 = rand() % 10 + 48;
		edited = false;
	}
	COORD c = g_Console.getConsoleSize();
	if (p)
	{
		if (a == Trial1)
		{
			a5 = true;
		}
		if (b == Trial2)
		{
			a2 = true;
		}
		if (d == Trial3)
		{
			a3 = true;
		}
		if (e == Trial4)
		{
			a4 = true;
		}
		if (f == Trial5)
		{
			a6 = true;
		}
		if (g == Trial6)
		{
			a7 = true;
		}
	}
	if (a == Trial1 && b == Trial2 && d == Trial3 && e == Trial4 && f == Trial5 && g == Trial6 && g_abKeyPressed[K_SPACE])
	{
		g_eGameState = S_GAME;
		if (aLevel1[player.Y + 1][player.X] == 2)
		{
			aLevel1[player.Y + 1][player.X] = 0;
		}
		else if (aLevel1[player.Y - 1][player.X] == 2)
		{
			aLevel1[player.Y - 1][player.X] = 0;
		}
		else if (aLevel1[player.Y][player.X + 1] == 2)
		{
			aLevel1[player.Y][player.X + 1] = 0;
		}
		else if (aLevel1[player.Y][player.X - 1] == 2)
		{
			aLevel1[player.Y][player.X - 1] = 0;
		}
		a5 = false; a2 = false; a3 = false; a4 = false; a6 = false; a7 = false;
		pc1 = false; pc2 = false; pc3 = false; pc4 = false; pc5 = false; pc6 = false; g_pChar.m_cLocation2.X = 37;
		enemy = false; edited = true;
		tries = 57;
		a = 48; b = 48; d = 48; e = 48; f = 48; g = 48;
	}
	if (p)
	{
		if (a == Trial2 || a == Trial3 || a == Trial4 || d == Trial5 || f == Trial6)
		{
			pc1 = true;
		}
		if (b == Trial1 || b == Trial3 || b == Trial4 || d == Trial5 || f == Trial6)
		{
			pc2 = true;
		}
		if (d == Trial1 || d == Trial2 || d == Trial4 || d == Trial5 || f == Trial6)
		{
			pc3 = true;
		}
		if (e == Trial1 || e == Trial2 || e == Trial3 || e == Trial5 || f == Trial6)
		{
			pc4 = true;
		}
		if (f == Trial1 || f == Trial2 || f == Trial3 || f == Trial4 || f == Trial6)
		{
			pc5 = true;
		}
		if (f == Trial1 || f == Trial2 || f == Trial3 || f == Trial4 || g == Trial5)
		{
			pc6 = true;
		}
		p = false;
	}
	if (tries == 48)
	{
		g_eGameState = S_GAME;
		if (aLevel1[player.Y + 1][player.X] == 2 && aLevel1[player.Y - 1][player.X] == 0)
		{
			g_sChar.m_cLocation.Y -= 2;
		}
		if (aLevel1[player.Y - 1][player.X] == 2 && aLevel1[player.Y + 1][player.X] == 0)
		{
			g_sChar.m_cLocation.Y += 2;
		}
		if (aLevel1[player.Y][player.X + 1] == 2 && aLevel1[player.Y][player.X - 1] == 0)
		{
			g_sChar.m_cLocation.X -= 2;
		}
		if (aLevel1[player.Y][player.X - 1] == 2 && aLevel1[player.Y][player.X + 1] == 0)
		{
			g_sChar.m_cLocation.X += 2;
		}
		a5 = false; a2 = false; a3 = false; a4 = false; a6 = false; a7 = false;
		pc1 = false; pc2 = false; pc3 = false; pc4 = false; pc5 = false; pc6 = false; g_pChar.m_cLocation2.X = 37;
		enemy = false; edited = true;
		tries = 57;
		a = 48; b = 48; d = 48; e = 48; f = 48; g = 48;
		Character.health -= 1;
	}
}*/

//////////////////////////////////
// Puzzle 1 - 64 (similar to 2048)
// Done by Zachary Wong
//////////////////////////////////

void puzzle1Move(int CurrentMap[10][30]) {
	int gameResult = 0;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	bool bSomethingHappenened = false;
	if (g_abKeyPressed[K_UP]) {
		gameResult = Puzzle64(K_UP, Puzzle1Map);
		bSomethingHappenened = true;
	}
	else if (g_abKeyPressed[K_DOWN]) {
		gameResult = Puzzle64(K_DOWN, Puzzle1Map);
		bSomethingHappenened = true;
	}
	else if (g_abKeyPressed[K_LEFT]) {
		gameResult = Puzzle64(K_LEFT, Puzzle1Map);
		bSomethingHappenened = true;
	}
	else if (g_abKeyPressed[K_RIGHT]) {
		gameResult = Puzzle64(K_RIGHT, Puzzle1Map);
		bSomethingHappenened = true;
	}
	if (bSomethingHappenened) {
		g_dBounceTime = g_dElapsedTime + 0.200;
	}
	switch (gameResult) {
	case -1:
		if (PuzzlePractice)
			g_eGameState = S_PUZZLE_PRACTICE;
		else {
			g_eGameState = S_GAME;
			Character.health--;
		}
		newGame = true;
		// failed
		break;
	case 0:
		// continues loop
		break;
	case 1:
		if (PuzzlePractice)
			g_eGameState = S_PUZZLE_PRACTICE;
		else {
			g_eGameState = S_GAME;
			if (CurrentMap[player.Y + 1][player.X] == 2)
			{
				CurrentMap[player.Y + 1][player.X] = 0;
			}
			else if (CurrentMap[player.Y - 1][player.X] == 2)
			{
				CurrentMap[player.Y - 1][player.X] = 0;
			}
			else if (CurrentMap[player.Y][player.X + 1] == 2)
			{
				CurrentMap[player.Y][player.X + 1] = 0;
			}
			else if (CurrentMap[player.Y][player.X - 1] == 2)
			{
				CurrentMap[player.Y][player.X - 1] = 0;
			}
			Character.money++;
			// Win
		}
		newGame = true;
		break;
	}
}
void Puzzle1Reset() { // Resets puzzle
	for (int x = 0; x < 4; x++) {
		for (int y = 0; y < 4; y++) {
			Puzzle1Map[x][y] = 0;
		}
	}
}
void renderPuzzle1() {
	COORD c;
	c.Y = 5;
	c.X = 2;
	g_Console.writeToBuffer(c, "Colour Combine!");
	c.Y = g_Console.getConsoleSize().Y / 5;
	for (int i = 0; i < 8; i++) {
		c.X = (g_Console.getConsoleSize().X / 4) * 3;
		switch (i) {
		case 0:
			g_Console.writeToBuffer(c, " ", 0x00);
			break;
		case 1:
			g_Console.writeToBuffer(c, " ", 0xFF9999);
			break;
		case 2:
			g_Console.writeToBuffer(c, " ", 0xFFAAAA);
			break;
		case 3:
			g_Console.writeToBuffer(c, " ", 0xFFBBBB);
			break;
		case 4:
			g_Console.writeToBuffer(c, " ", 0xFFCCCC);
			break;
		case 5:
			g_Console.writeToBuffer(c, " ", 0xFFDDDD);
			break;
		case 6:
			g_Console.writeToBuffer(c, " ", 0xFFFFFF);
			break;
		case 7:
			g_Console.writeToBuffer(c, "Combine two tile 6s to win!");
			break;
		}
		c.X++;
		switch (i) {
		case 0:
			g_Console.writeToBuffer(c, "-  Tile 0 (Vacant)");
			break;
		case 1:
			g_Console.writeToBuffer(c, "- Tile 1");
			break;
		case 2:
			g_Console.writeToBuffer(c, "- Tile 2");
			break;
		case 3:
			g_Console.writeToBuffer(c, "- Tile 3");
			break;
		case 4:
			g_Console.writeToBuffer(c, "- Tile 4");
			break;
		case 5:
			g_Console.writeToBuffer(c, "- Tile 5");
			break;
		case 6:
			g_Console.writeToBuffer(c, "- Tile 6");
			break;
		}
		c.Y += 2;
	}
	c.Y = g_Console.getConsoleSize().Y / 5;
	c.X = g_Console.getConsoleSize().X / 5;
	for (int y = 0; y < 4; y++, c.Y += 3) {
		c.X = g_Console.getConsoleSize().X / 3;
		for (int x = 0; x < 4; x++, c.X += 3) {
			for (int i = 0; i < 9; i++) {
				switch (i) {
				case 0:
					c.X++;
					break;
				case 1:
					c.X++;
					break;
				case 2:
					c.Y++;
					break;
				case 3:
					c.X--;
					break;
				case 4:
					c.X--;
					break;
				case 5:
					c.Y++;
					break;
				case 6:
					c.X++;
					break;
				case 7:
					c.X++;
					break;
				case 8:
					c.X -= 2;
					c.Y -= 2;
					break;
				}
				switch (Puzzle1Map[y][x]) {
				case 0:
					g_Console.writeToBuffer(c, " ", 0x00);
					break;
				case 1:
					g_Console.writeToBuffer(c, " ", 0xFF9999);
					break;
				case 2:
					g_Console.writeToBuffer(c, " ", 0xFFAAAA);
					break;
				case 3:
					g_Console.writeToBuffer(c, " ", 0xFFBBBB);
					break;
				case 4:
					g_Console.writeToBuffer(c, " ", 0xFFCCCC);
					break;
				case 5:
					g_Console.writeToBuffer(c, " ", 0xFFDDDD);
					break;
				case 6:
					g_Console.writeToBuffer(c, " ", 0xFFFFFF);
					break;
				}
			}
		}
	}
	return;
}

////////////////////////////////////
// Puzzle 2 - Red Light, Green Light
// Done by Ong Yan Fei
////////////////////////////////////

void Puzzle2() {

}
void renderPuzzle2() {

}

void MapLayout()
{
	std::ifstream inFile;
	std::string line;
	std::string MapLayout1[30][10];
	COORD c;

	inFile.open("Map Layouts\\MapLayoutLv1.txt");

	if (!inFile)
	{
		g_Console.writeToBuffer(1, 1, "File Error", 0x00);
	}

	if (inFile.is_open())
	{
		for (int y = 0; y < 10; y++)
		{
			getline(inFile, line);
			line += '\n';

			for (int x = 0; x < 30; x++)
			{
				MapLayout1[x][y] = line[x];
			}

		}

		inFile.close();
		c.Y = 6;
		for (int x = 0; x < 10; x++, c.Y++)
		{
			c.X = 8;
			for (int y = 0; y < 30; y++, c.X++)
			{

				g_Console.writeToBuffer(c, MapLayout1[x][y], 0x00);

			}

		}

	}
	c.Y++;

	inFile.open("Map Layouts\\MapLayoutLv2.txt");

	if (!inFile)
	{
		g_Console.writeToBuffer(c, "File Error", 0x00);
	}

	if (inFile.is_open())
	{
		for (int y = 0; y < 10; y++)
		{
			getline(inFile, line);
			line += '\n';

			for (int x = 0; x < 30; x++)
			{
				MapLayout1[x][y] = line[x];
			}

		}

		inFile.close();

		for (int x = 0; x < 10; x++, c.Y++)
		{
			c.X = 8;
			for (int y = 0; y < 30; y++, c.X++)
			{

				g_Console.writeToBuffer(c, MapLayout1[x][y], 0x00);

			}

		}

	}

	c.Y++;

	inFile.open("Map Layouts\\MapLayoutLv3.txt");

	if (!inFile)
	{
		g_Console.writeToBuffer(c, "File Error", 0x00);
	}

	if (inFile.is_open())
	{
		for (int y = 0; y < 10; y++)
		{
			getline(inFile, line);
			line += '\n';

			for (int x = 0; x < 30; x++)
			{
				MapLayout1[x][y] = line[x];
			}

		}

		inFile.close();

		for (int x = 0; x < 10; x++, c.Y++)
		{
			c.X = 8;
			for (int y = 0; y < 30; y++, c.X++)
			{

				g_Console.writeToBuffer(c, MapLayout1[x][y], 0x00);

			}

		}

	}


}

///////////////////////////////////////
// Puzzle 3 (Floor 1 Boss) - Riddler
// Done By Liew Ming Qian
///////////////////////////////////////

P_RIDDLER Riddler_State;
void initRiddles() {

	riddlerInitialized = true;
}
void moveriddles()
{

	bool bSomethingHappened = false;
	if (g_dBounceTime > g_dElapsedTime)
		return;

	g_sChar.m_cLocation.X = 9;
	if (g_sChar.m_cLocation.Y < 10)
	{
		g_sChar.m_cLocation.Y = 13;
	}
	if (g_sChar.m_cLocation.Y > 13)
	{
		g_sChar.m_cLocation.Y = 10;
	}
	if (g_abKeyPressed[K_UP] && g_sChar.m_cLocation.Y > 0)
	{
		//Beep(1440, 30);
		g_sChar.m_cLocation.Y--;
		bSomethingHappened = true;
	}

	if (g_abKeyPressed[K_DOWN] && g_sChar.m_cLocation.Y < g_Console.getConsoleSize().Y - 1)
	{
		//Beep(1440, 30);
		g_sChar.m_cLocation.Y++;
		bSomethingHappened = true;
	}
	if (g_abKeyPressed[K_SPACE] && Riddler_State == R_QUESTION1 && !bSomethingHappened)
	{
		bSomethingHappened = true;
		if (g_sChar.m_cLocation.Y == 10) { Riddler_State = R_QUESTION2; }
		else { Riddler_State = R_FAIL; }
	}
	if (g_abKeyPressed[K_SPACE] && Riddler_State == R_QUESTION2 && !bSomethingHappened)
	{
		bSomethingHappened = true;
		if (g_sChar.m_cLocation.Y == 13) { Riddler_State = R_QUESTION3; }
		else { Riddler_State = R_FAIL; }
	}
	if (g_abKeyPressed[K_SPACE] && Riddler_State == R_QUESTION3 && !bSomethingHappened)
	{
		bSomethingHappened = true;
		if (g_sChar.m_cLocation.Y == 13) { Riddler_State = R_QUESTION4; }
		else { Riddler_State = R_FAIL; }

	}
	if (g_abKeyPressed[K_SPACE] && Riddler_State == R_QUESTION4 && !bSomethingHappened)
	{
		bSomethingHappened = true;
		if (g_sChar.m_cLocation.Y == 12) { Riddler_State = R_QUESTION5; }
		else { Riddler_State = R_FAIL; }

	}
	if (g_abKeyPressed[K_SPACE] && Riddler_State == R_QUESTION5 && !bSomethingHappened)
	{
		bSomethingHappened = true;
		if (g_sChar.m_cLocation.Y == 11) { Riddler_State = R_QUESTION6; }
		else { Riddler_State = R_FAIL; }
	}
	if (g_abKeyPressed[K_SPACE] && Riddler_State == R_QUESTION6 && !bSomethingHappened)
	{
		bSomethingHappened = true;
		if (g_sChar.m_cLocation.Y == 13) { Riddler_State = R_PASS; }
		else { Riddler_State = R_FAIL; }
	}
	if (g_abKeyPressed[K_SPACE] && Riddler_State == R_PASS && !bSomethingHappened)
	{
		bSomethingHappened = true;
		g_sChar.m_cLocation = P_FinalPosition;
		g_eGameState = S_NEXTLEVEL;
		Character.money += 10;
	}

	if (g_abKeyPressed[K_SPACE] && Riddler_State == R_FAIL && !bSomethingHappened)
	{
		bSomethingHappened = true;
		g_eGameState = S_GAME;
		g_sChar.m_cLocation = P_FinalPosition;
		Character.health -= 1;
		Riddler_State = R_QUESTION1;
	}

	if (bSomethingHappened)
	{
		// set the bounce time to some time in the future to prevent accidental triggers
		g_dBounceTime = g_dElapsedTime + 0.2; // 125ms should be enough
	}

}

void renderiddles()
{
	WORD charColor = 0x0C;
	if (g_sChar.m_bActive)
	{
		charColor = 0x0A;
	}
	g_Console.writeToBuffer(g_sChar.m_cLocation, ">", charColor);
	COORD c;
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);
	const WORD colors[] =
	{
		0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
		0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
	};

	c.X = 10;

	if (Riddler_State == R_QUESTION1)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "Riddler: If you answer my riddles correctly, you may pass", colors[1]);
		c.Y = 8;
		g_Console.writeToBuffer(c, "But if you get them wrong, be prepared to suffer, Ready? ", colors[1]);
		c.Y = 10;
		g_Console.writeToBuffer(c, "Yes", colors[2]);
		c.Y = 11;
		g_Console.writeToBuffer(c, "Maybe", colors[2]);
		c.Y = 12;
		g_Console.writeToBuffer(c, "No", colors[2]);
		c.Y = 13;
		g_Console.writeToBuffer(c, "Lol the Riddler", colors[2]);
	}

	if (Riddler_State == R_QUESTION2)
	{

		c.Y = 7;
		g_Console.writeToBuffer(c, "I have a mouth but do not speek, I have a bed but do not sleep,");
		c.Y = 8;
		g_Console.writeToBuffer(c, "I run every where but go know were, what am I?");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a. Starfish");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b. Jellyfish");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c. Ocean");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d. River");

	}

	if (Riddler_State == R_QUESTION3)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "I have a head and a tail, but no legs , what am I?");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a. A tadpole");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b. A snake");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c. A Salmon");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d. A coin");

	}


	if (Riddler_State == R_QUESTION4)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "The more you take, the more you leave behind. what am I?");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a. Loans");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b. Children");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c. Footprints");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d. Investment");
	}

	if (Riddler_State == R_QUESTION5)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "I am the beginning of the End, and the End of time and space");
		c.Y = 8;
		g_Console.writeToBuffer(c, "I am Essential to creation, and I surround every place.");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a. Dark matter");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b. The letter E");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c. Death");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d. Azatoth");

	}


	if (Riddler_State == R_QUESTION6)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "I look like the Statue of Liberty, I look like surprised pikachu");
		c.Y = 9;
		g_Console.writeToBuffer(c, "And I like movies and math, Who am I?");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a.Frederic Auguste Bartholdi");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b.Carl Gauss");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c.Serena Gomez");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d.Mr Tang of Nanyang Poly");
	}
	if (Riddler_State == R_PASS)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "You solved my riddles?? But I am THE RIDDLER!");
		c.Y = 8;
		g_Console.writeToBuffer(c, "THIS IS IMPOSSIBLE!!!!!! I AM UNBEATABLE!!");
		c.Y = 10;
		g_Console.writeToBuffer(c, "Soka..");
		c.Y = 11;
		g_Console.writeToBuffer(c, "Hao..");
		c.Y = 12;
		g_Console.writeToBuffer(c, "Theek...");
		c.Y = 13;
		g_Console.writeToBuffer(c, "Ok...");
	}

	if (Riddler_State == R_FAIL)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "That is the WRONG answer!! You take one damage from Riddler!");
		c.Y = 8;
		g_Console.writeToBuffer(c, "TRY AGAIN?(You have no choice)");
		c.Y = 10;
		g_Console.writeToBuffer(c, "Yes!");
		c.Y = 11;
		g_Console.writeToBuffer(c, "Yas");
		c.Y = 12;
		g_Console.writeToBuffer(c, "Yes...");
		c.Y = 13;
		g_Console.writeToBuffer(c, "Yes?");

	}
	renderstats();


}

//////////////////////////////////
// Puzzle 4 - (Floor 2 Boss) - Rhythm
// Done by Dave Philipus Wijaya
//////////////////////////////////
void renderMap4()
{
	COORD c;
	c.Y = 5;
	c.X = 2;
	g_Console.writeToBuffer(c, "Rythm!");
	c.Y = g_Console.getConsoleSize().Y / 5;
	c.X = g_Console.getConsoleSize().X / 5;
	for (int y = 0; y < 7; y++, c.Y += 3) {
		c.X = g_Console.getConsoleSize().X / 3;
		for (int x = 0; x < 4; x++, c.X += 3) {
			for (int i = 0; i < 9; i++) {
				switch (i) {
				case 0:
					c.X++;
					break;
				case 1:
					c.X++;
					break;
				case 2:
					c.Y++;
					break;
				case 3:
					c.X--;
					break;
				case 4:
					c.X--;
					break;
				case 5:
					c.Y++;
					break;
				case 6:
					c.X++;
					break;
				case 7:
					c.X++;
					break;
				case 8:
					c.X -= 2;
					c.Y -= 2;
					break;
				}
				switch (Bullet1Map[y][x]) {
				case 0:
					g_Console.writeToBuffer(c, " ", 0x00);
					break;
				case 1:
					g_Console.writeToBuffer(c, " ", 0xFF9999);
					break;
				case 2:
					g_Console.writeToBuffer(c, " ", 0xFFAAAA);
					break;
				case 3:
					g_Console.writeToBuffer(c, " ", 0xFFBBBB);
					break;
				case 4:
					g_Console.writeToBuffer(c, " ", 0xFFCCCC);
					break;
				}
			}
		}
	}
	c.Y = 8;
	c.X = 2;
	if (perfect)
		g_Console.writeToBuffer(c, "Perfect");
	else if (good)
		g_Console.writeToBuffer(c, "Good");
	else if (cool)
		g_Console.writeToBuffer(c, "cool");
	else if (miss)
		g_Console.writeToBuffer(c, "miss");
	c.Y = 10;
	c.X = 2;
	g_Console.writeToBuffer(c, "Boss Patience: ", 7);
	c.X = 17;
	g_Console.writeToBuffer(c, tries, 7);
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);
	ss.str("");
	ss << "Combo: " << combo;
	c.X = 2;
	c.Y = 12;
	g_Console.writeToBuffer(c, ss.str(), 7);
	ss.str("");
	c.Y = 14;
	ss << "Point: " << point4;
	g_Console.writeToBuffer(c, ss.str(), 7);
	if (combo > 10)
	{
		c.Y = 10;
		c.X = 45;
		g_Console.writeToBuffer(c, "Dance!Dance!");
		if (tries >= 54)
		{
			c.Y = 12;
			g_Console.writeToBuffer(c, "You are doing a great job");
		}
		else if (tries < 54)
		{
			c.Y = 12;
			g_Console.writeToBuffer(c, "Fianlly you are dancing");
		}
	}
	if (tries <= 55 && tries > 53)
	{
		c.Y = 2;
		c.X = 30;
		g_Console.writeToBuffer(c, "You are not a great dancer are you?");
	}
	if (tries <= 53 && tries > 50)
	{
		c.Y = 2;
		c.X = 30;
		g_Console.writeToBuffer(c, "You are really bad");
	}
	if (tries <= 50 && tries > 48)
	{
		c.Y = 2;
		c.X = 30;
		g_Console.writeToBuffer(c, "It really pains me to watch you dance");
	}
	if (tries <= 48)
	{
		c.Y = 2;
		c.X = 30;
		g_Console.writeToBuffer(c, "Stop dancing,You will still listen to my singing ");
	}
}
void Puzzle4Move()
{
	bool bSomethingHappened = false;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	if (g_abKeyPressed[K_DOWN])
	{
		g_bChar.m_cLocation4.X = 37;
		if (g_eChar.m_cLocation5.X == 37 && g_eChar.m_cLocation5.Y > 8 && g_eChar.m_cLocation5.Y < 13)
		{
			if (g_eChar.m_cLocation5.Y - 1 == g_bChar.m_cLocation4.Y)
			{
				perfect = true;
				miss = false;
				good = false;
				cool = false;
				point4 += 50 + 10 * combo;
				combo++;
			}
			else if (g_eChar.m_cLocation5.Y - 2 == g_bChar.m_cLocation4.Y || g_eChar.m_cLocation5.Y - 3 == g_bChar.m_cLocation4.Y)
			{
				perfect = false;
				miss = false;
				good = true;
				cool = false;
				point4 += 25 + 5 * combo;
				combo++;
			}
			else if (g_eChar.m_cLocation5.Y - 4 == g_bChar.m_cLocation4.Y)
			{
				perfect = false;
				miss = false;
				good = false;
				cool = true;
				point4 += 10 + 2 * combo;
				combo = 0;
			}
			g_eChar.m_cLocation5.Y = 28;
		}
		else
		{
			g_eChar.m_cLocation5.Y = 8;
		}
		bSomethingHappened = true;
	}
	if (g_abKeyPressed[K_UP])
	{
		g_bChar.m_cLocation4.X = 34;
		if (g_eChar.m_cLocation5.X == 34 && g_eChar.m_cLocation5.Y > 8 && g_eChar.m_cLocation5.Y < 13)
		{
			if (g_eChar.m_cLocation5.Y - 1 == g_bChar.m_cLocation4.Y)
			{
				perfect = true;
				miss = false;
				good = false;
				cool = false;
				point4 += 50 + 10 * combo;
				combo++;
			}
			else if (g_eChar.m_cLocation5.Y - 2 == g_bChar.m_cLocation4.Y || g_eChar.m_cLocation5.Y - 3 == g_bChar.m_cLocation4.Y)
			{
				perfect = false;
				miss = false;
				good = true;
				cool = false;
				point4 += 25 + 5 * combo;
				combo++;
			}
			else if (g_eChar.m_cLocation5.Y - 4 == g_bChar.m_cLocation4.Y)
			{
				perfect = false;
				miss = false;
				good = false;
				cool = true;
				point4 += 10 + 2 * combo;
				combo = 0;
			}
			g_eChar.m_cLocation5.Y = 28;
		}
		else
		{
			g_eChar.m_cLocation5.Y = 8;
		}
		bSomethingHappened = true;
	}
	if (g_abKeyPressed[K_LEFT])
	{
		g_bChar.m_cLocation4.X = 31;
		if (g_eChar.m_cLocation5.X == 31 && g_eChar.m_cLocation5.Y > 8 && g_eChar.m_cLocation5.Y < 13)
		{
			if (g_eChar.m_cLocation5.Y - 1 == g_bChar.m_cLocation4.Y)
			{
				perfect = true;
				miss = false;
				good = false;
				cool = false;
				point4 += 50 + 10 * combo;
				combo++;
			}
			else if (g_eChar.m_cLocation5.Y - 2 == g_bChar.m_cLocation4.Y || g_eChar.m_cLocation5.Y - 3 == g_bChar.m_cLocation4.Y)
			{
				perfect = false;
				miss = false;
				good = true;
				cool = false;
				point4 += 25 + 5 * combo;
				combo++;
			}
			else if (g_eChar.m_cLocation5.Y - 4 == g_bChar.m_cLocation4.Y)
			{
				perfect = false;
				miss = false;
				good = false;
				cool = true;
				point4 += 10 + 2 * combo;
				combo = 0;
			}
			g_eChar.m_cLocation5.Y = 28;
		}
		else
		{
			g_eChar.m_cLocation5.Y = 8;
		}
		bSomethingHappened = true;
	}
	if (g_abKeyPressed[K_RIGHT])
	{
		g_bChar.m_cLocation4.X = 40;
		if (g_eChar.m_cLocation5.X == 40 && g_eChar.m_cLocation5.Y > 8 && g_eChar.m_cLocation5.Y < 13)
		{
			if (g_eChar.m_cLocation5.Y - 1 == g_bChar.m_cLocation4.Y)
			{
				perfect = true;
				miss = false;
				good = false;
				cool = false;
				point4 += 50 + 10 * combo;
				combo++;
			}
			else if (g_eChar.m_cLocation5.Y - 2 == g_bChar.m_cLocation4.Y || g_eChar.m_cLocation5.Y - 3 == g_bChar.m_cLocation4.Y)
			{
				perfect = false;
				miss = false;
				good = true;
				cool = false;
				point4 += 25 + 5 * combo;
				combo++;
			}
			else if (g_eChar.m_cLocation5.Y - 4 == g_bChar.m_cLocation4.Y)
			{
				perfect = false;
				miss = false;
				good = false;
				cool = true;
				point4 += 10 + 2 * combo;
				combo = 0;
			}
			g_eChar.m_cLocation5.Y = 28;
		}
		else
		{
			g_eChar.m_cLocation5.Y = 8;
		}
		bSomethingHappened = true;
	}
	if (g_eChar.m_cLocation5.Y <= 8)
	{
		perfect = false;
		miss = true;
		good = false;
		cool = false;
		combo = 0;
	}
	if (bSomethingHappened)
	{
		// set the bounce time to some time in the future to prevent accidental triggers
		g_dBounceTime = g_dElapsedTime + 0.4; // 125ms should be enough
	}
}
void EnemyBullet()
{
	if (g_eChar.m_cLocation5.Y == 28)
		x = rand() % 4;
	if (g_eChar.m_cLocation5.Y < 28 && g_eChar.m_cLocation5.Y > 7)
	{
		switch (x)
		{
		case 0:
		{
			g_eChar.m_cLocation5.X = 31;
			g_Console.writeToBuffer(g_eChar.m_cLocation5, 27, 7);
			break;
		}
		case 1:
		{
			g_eChar.m_cLocation5.X = 34;
			g_Console.writeToBuffer(g_eChar.m_cLocation5, 24, 7);
			break;
		}
		case 2:
		{
			g_eChar.m_cLocation5.X = 37;
			g_Console.writeToBuffer(g_eChar.m_cLocation5, 25, 7);
			break;
		}
		case 3:
		{
			g_eChar.m_cLocation5.X = 40;
			g_Console.writeToBuffer(g_eChar.m_cLocation5, 26, 7);
			break;
		}
		}
	}
}
void moveEnemyBullet()
{
	bool bSomethingHappened = false;
	if (g_dBounceTime2 > g_dElapsedTime)
		return;
	if (g_eChar.m_cLocation5.Y >= 8)
	{
		g_eChar.m_cLocation5.Y--;
	}
	else
		g_eChar.m_cLocation5.Y = 28;
	if (g_eChar.m_cLocation5.Y == 7)
	{
		if (tries > 48)
			tries--;
	}
	bSomethingHappened = true;
	if (g_dPuzzleTimer == 0 && tries > 48)
	{
		bSomethingHappened = true;
		g_sChar.m_cLocation = P_FinalPosition;
		g_eGameState = S_NEXTLEVEL;
		if(point4<1000)
		Character.money += 10;
		if (point4 < 3000 && point4>=1000)
			Character.money += 20;
		if (point4 < 4000 && point4 >= 3000)
			Character.money += 25;
		if (point4 >= 5000)
		{
			Character.money += 30;
		}
	}
	else if (g_dPuzzleTimer == 0 && tries == 48)
	{
		bSomethingHappened = true;
		g_eGameState = S_GAME;
		g_sChar.m_cLocation = P_FinalPosition;
		Character.health -= 1;
	}
	if (bSomethingHappened)
	{
		// set the bounce time to some time in the future to prevent accidental triggers
		g_dBounceTime2 = g_dElapsedTime + 0.045; // 125ms should be enough
		if (combo >= 5)
		{
			g_dBounceTime2 = g_dElapsedTime + 0.043;
		}
		if (combo >= 10)
		{
			g_dBounceTime2 = g_dElapsedTime + 0.04;
		}
		if (combo >= 15)
		{
			g_dBounceTime2 = g_dElapsedTime + 0.037;
		}
		if (combo >= 20)
		{
			g_dBounceTime2 = g_dElapsedTime + 0.033;
		}
		if (combo >= 25)
		{
			g_dBounceTime2 = g_dElapsedTime + 0.028;
		}
		if (combo >= 30)
		{
			g_dBounceTime2 = g_dElapsedTime + 0.020;
		}
	}
}
void Puzzle4Char()
{
	COORD c;
	WORD charColor = 0x0C;
	if (g_sChar.m_bActive)
	{
		charColor = 0x0A;
	}
	c.Y = 8;
	c.X = 31;
	g_Console.writeToBuffer(c, 27);
	c.X = 34;
	g_Console.writeToBuffer(c, 24);
	c.X = 37;
	g_Console.writeToBuffer(c, 25);
	c.X = 40;
	g_Console.writeToBuffer(c, 26);
	if (g_bChar.m_cLocation4.X == 31)
		g_Console.writeToBuffer(g_bChar.m_cLocation4, 27, charColor);
	if (g_bChar.m_cLocation4.X == 34)
		g_Console.writeToBuffer(g_bChar.m_cLocation4, 24, charColor);
	if (g_bChar.m_cLocation4.X == 37)
		g_Console.writeToBuffer(g_bChar.m_cLocation4, 25, charColor);
	if (g_bChar.m_cLocation4.X == 40)
		g_Console.writeToBuffer(g_bChar.m_cLocation4, 26, charColor);
}
void renderPuzzle4()
{
	renderMap4();
	moveEnemyBullet();
	EnemyBullet();
	Puzzle4Move();
	Puzzle4Char();
	return;
}

///////////////////////////////////////
// Shop and Inventory
///////////////////////////////////////

void updateShop()
{
	struct item
	{
		std::string name[8] = { "  Lamp  ","  Heart  ","  Present  ", "  Hourglass  ", "  Trap ", "  Clover  " };
		int price[8] = { 10,7,5,10,15,12,15 };
		int numbers[8];
	};
	struct item buy;

	enum items
	{
		Lamp,
		Heart,
		Present,
		Hourglass,
		Trap,
		Clover,
		Exit,
		Count
	};
	bool bSomethingHappened = false;
	WORD charColor = 0x0C;
	if (g_sChar.m_bActive)
	{
		charColor = 0x0A;
	}
	g_sChar.m_cLocation.X = 29;
	if (g_sChar.m_cLocation.Y < 10)
		g_sChar.m_cLocation.Y = 10 + Count;
	if (g_sChar.m_cLocation.Y > 17)
		g_sChar.m_cLocation.Y = 10 + Count;
	g_Console.writeToBuffer(g_sChar.m_cLocation, ">", charColor);
	if (g_dBounceTime > g_dElapsedTime)
		return;
	if (g_abKeyPressed[K_UP] && g_sChar.m_cLocation.Y > 0)
	{
		//Beep(1440, 30);
		g_sChar.m_cLocation.Y--;
		bSomethingHappened = true;
	}

	if (g_abKeyPressed[K_DOWN] && g_sChar.m_cLocation.Y < g_Console.getConsoleSize().Y - 1)
	{
		//Beep(1440, 30);
		g_sChar.m_cLocation.Y++;
		bSomethingHappened = true;
	}

	if (g_abKeyPressed[K_SPACE] && g_eGameState == S_SHOP)
	{
		if (g_sChar.m_cLocation.Y > 10)
		{
			options = g_sChar.m_cLocation.Y - 10;
			bSomethingHappened = true;
		}
		g_sChar.m_bActive = !g_sChar.m_bActive;
		bSomethingHappened = true;
		if (options == Lamp && Character.money >= 5 && Inv.lamp == 0)
		{
			Character.money -= 5;
			Inv.lamp = 1;
			buy.numbers[Flash] = +1;
			options = 0;
			bSomethingHappened = true;
		}
		if (options == Heart && Character.money >= 7)
		{
			Character.health += 1;
			Character.money -= 7;
			options = 0;
			bSomethingHappened = true;
		}
		if (options == Present && Character.money >= 6)
		{
			Inv.present += 1;
			Character.money -= 6;
			options = 0;
			bSomethingHappened = true;
		}
		if (options == Hourglass && Character.money >= 6)
		{
			Inv.hourglass += 1;
			Character.money -= 6;
			options = 0;
			bSomethingHappened = true;
		}

		if (options == Clover && Character.money >= 7)
		{
			Inv.clover += 1;
			Character.money -= 7;
			options = 0;
			bSomethingHappened = true;
		}
		if (options == Trap && Character.money >= 9)
		{
			Inv.trap += 1;
			Character.money -= 9;
			options = 0;
			bSomethingHappened = true;
		}
		if (options == Exit)
		{
			options = 0;
			g_eGameState = S_GAME;
			g_sChar.m_cLocation = P_FinalPosition;
			bSomethingHappened = true;
		}
		renderstats();

	}

	void renderInventory(std::string Inventory);

	if (bSomethingHappened)
	{
		// set the bounce time to some time in the future to prevent accidental triggers
		g_dBounceTime = g_dElapsedTime + 0.125; // 125ms should be enough
	}

}

void renderShop()
{
	renderstats();
	updateShop();
	COORD c;
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);
	const WORD colors[] =
	{
		0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
		0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
	};
	enum items
	{
		Lamp,
		Heart,
		Present,
		Hourglass,
		Bombs,
		Clover,
		Exit,
		Count
	};

	c.Y = 5; c.X = 30;
	g_Console.writeToBuffer(c, "Merchant Tom", colors[1]);
	c.Y = 6;
	g_Console.writeToBuffer(c, "Welcome to my shop");
	c.Y = 7;
	g_Console.writeToBuffer(c, "What would you like to buy?");

	c.Y = 10 + Lamp;
	g_Console.writeToBuffer(c, "Lamp : $5", colors[4]);
	c.Y = 10 + Heart;
	g_Console.writeToBuffer(c, "Extra hearts : $7", colors[4]);
	if (options == Heart) { g_Console.writeToBuffer(c, "Extra hearts : $5 (Get an extra heart)", colors[4]); }
	c.Y = 10 + Present;
	g_Console.writeToBuffer(c, "Present : $6", colors[4]);
	if (options == Present) { g_Console.writeToBuffer(c, "Present : $6 (Use to bribe normal enemies, 50%)", colors[4]); }
	c.Y = 10 + Hourglass;
	if (options == Hourglass) { g_Console.writeToBuffer(c, "Hourglass : $5 (Increase time in puzzles by 10 sec)", colors[4]); }
	g_Console.writeToBuffer(c, "Hourglass : $6", colors[4]);
	c.Y = 10 + Bombs;
	g_Console.writeToBuffer(c, "Bomb : $9", colors[4]);
	if (options == Bombs) { g_Console.writeToBuffer(c, "Bomb : $9 (Destroys enemy, E to detonate, 100%)", colors[4]); }
	c.Y = 10 + Clover;
	g_Console.writeToBuffer(c, "Clover : $7", colors[4]);
	if (options == Clover) { g_Console.writeToBuffer(c, "Clover : $5 (Increase gold drops by 1,stacks", colors[4]); }
	c.Y = 10 + Exit;
	g_Console.writeToBuffer(c, "Exit shop", colors[4]);
	if (Inv.lamp != 0)
	{
		c.Y = 10 + Lamp;
		g_Console.writeToBuffer(c, "Out of stock", colors[4]);
	}

}

void renderInventory()
{
	COORD c;
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);

	c.X = 5;
	c.Y = 25;

	for (int j = 0; j < 3; j++)
	{
		for (int i = 0; i < 75; i++)
		{
			c.X = i + 5;
			c.Y = 25 + j;
			g_Console.writeToBuffer(c, " ", 0xF6);
		}
	}
	int trap = 48 + Inv.trap;
	int gift = 48 + Inv.present;
	int luck = 48 + Inv.clover;
	int hour = 48 + Inv.hourglass;
	c.X = 5;
	c.Y = 25;
	g_Console.writeToBuffer(c, "1. Traps", 0xF6);
	c.X += 20;
	g_Console.writeToBuffer(c, "2. Presents", 0xF6);
	c.X += 20;
	g_Console.writeToBuffer(c, "3. Clovers", 0xF6);
	c.X += 20;
	g_Console.writeToBuffer(c, "4. Hourglasses", 0xF6);
	c.X = 5;
	c.Y = 26;
	g_Console.writeToBuffer(c, (char)trap, 0xF6);
	c.X += 20;
	g_Console.writeToBuffer(c, (char)gift, 0xF6);
	c.X += 20;
	g_Console.writeToBuffer(c, (char)luck, 0xF6);
	c.X += 20;
	g_Console.writeToBuffer(c, (char)hour, 0xF6);
	c.X = 5;
	c.Y = 27;
	g_Console.writeToBuffer(c, "Number keys to use items", 0xF6);
	updateInventory();
}

void updateInventory()
{
	int time = 0;
	bool bSomethingHappened = false;
	WORD charColor = 0x0C;
	if (g_sChar.m_bActive)
	{
		charColor = 0x0A;
	}

	if (g_dBounceTime > g_dElapsedTime)
		return;
	if (g_abKeyPressed[K_ONE] && Inv.ready == 0 && Inv.trap > 0)
	{
		Inv.trap -= 1;
		trap.X = player.X;
		trap.Y = player.Y;
		Inv.trap -= 1;
		aLevel1[trap.Y][trap.X] = 6;
		Inv.ready = 1;
		bSomethingHappened = true;
	}

	if (Inv.ready == 1 && g_abKeyPressed[K_INT])
	{
		time = g_dElapsedTime + 10.000;
		Inv.trigger == 1;
		aLevel1[trap.Y + 1][trap.X] = 7;
		aLevel1[trap.Y - 1][trap.X] = 7;
		aLevel1[trap.Y][trap.X + 1] = 7;
		aLevel1[trap.Y][trap.X - 1] = 7;
		if (aLevel1[player.Y + 1][player.X] == 6)
		{
			Character.health = 0;
		}
		else if (aLevel1[player.Y - 1][player.X] == 6)
		{
			Character.health = 0;
		}
		else if (aLevel1[player.Y][player.X + 1] == 6)
		{
			Character.health = 0;
		}
		else if (aLevel1[player.Y][player.X - 1] == 6)
		{
			Character.health = 0;
		}
		aLevel1[trap.Y][trap.X] = 7;
		Inv.ready = 0;
		bSomethingHappened = true;
	}
	if (g_dElapsedTime > time)
	{
		if (Inv.trigger == 1 && g_dElapsedTime == time)
		{
			if (aLevel1[trap.Y + 1][trap.X] == 7)
			{
				aLevel1[trap.Y + 1][trap.X] = 0;
			}
			else if (aLevel1[trap.Y - 1][trap.X] == 7)
			{
				aLevel1[trap.Y - 1][trap.X] = 0;
			}
			else if (aLevel1[trap.Y][trap.X + 1] == 7)
			{
				aLevel1[trap.Y][trap.X + 1] = 0;
			}
			else if (aLevel1[trap.Y][trap.X - 1] == 7)
			{
				aLevel1[trap.Y][trap.X - 1] = 0;
			}
			Inv.trigger == 0;
			bSomethingHappened = true;
			trap.X = 0;
			trap.Y = 0;
		}
	}


	if (Inv.present > 0 && g_abKeyPressed[K_TWO] && (aLevel1[player.Y + 1][player.X] == 2 || aLevel1[player.Y - 1][player.X] == 2 || aLevel1[player.Y][player.X + 1] == 2 || aLevel1[player.Y][player.X - 1] == 2))
	{
		Inv.present -= 1;
		int chance = rand() % 2 + 1;
		if (chance == 1)
		{
			if (aLevel1[player.Y + 1][player.X] == 2)
			{
				aLevel1[player.Y + 1][player.X] = 0;
			}
			else if (aLevel1[player.Y - 1][player.X] == 2)
			{
				aLevel1[player.Y - 1][player.X] = 0;
			}
			else if (aLevel1[player.Y][player.X + 1] == 2)
			{
				aLevel1[player.Y][player.X + 1] = 0;
			}
			else if (aLevel1[player.Y][player.X - 1] == 2)
			{
				aLevel1[player.Y][player.X - 1] = 0;
			}
			bSomethingHappened = true;
		}

	}
	if (g_abKeyPressed[K_THREE] && Inv.clover > 0)
	{
		Inv.clover -= 1;
		Character.health += 1;
		bSomethingHappened = true;
	}

	if (g_abKeyPressed[K_FOUR] && g_eGameState == S_PUZZLE)
	{
		Inv.hourglass -= 1;
		bSomethingHappened = true;
	}

	if (bSomethingHappened)
	{
		// set the bounce time to some time in the future to prevent accidental triggers
		g_dBounceTime = g_dElapsedTime + 0.125; // 125ms should be enough
	}
}