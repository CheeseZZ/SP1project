#ifndef _RHYTHM_
#define _RHYTHM_
//For Movement of enemy will not interrupts movement of players
double  g_dBounceTime2;
//State of how far the enemy is when they click the button
bool good = false;
bool perfect = false;
bool cool = false;
bool miss = false;
//To keep track with the player stats in the rythm game 
int combo = 0;
int point4 = 0;
int x = 0;
#endif