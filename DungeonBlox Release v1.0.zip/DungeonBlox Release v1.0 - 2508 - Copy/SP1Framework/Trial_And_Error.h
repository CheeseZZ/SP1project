#ifndef _TRIAL_AND_ERROR_
#define _TRIAL_AND_ERROR_
// Puzzle 0 Variables //////////////////////////////////////////////////
COORD player;
COORD answer;
double g_dElapsedTime2;
int a = 48, b = 48, d = 48, e = 48;
//To check if player press the spacebar
bool checkingT = false;
//To make sure the correct answer stays on the screen
bool a1 = false;//needed because the first one apparently get reseted
bool a2 = false;
bool a3 = false;
bool a4 = false;
bool a5 = false;
//To make the partially correct answer stay on screen
bool pc1 = false;
bool pc2 = false;
bool pc3 = false;
bool pc4 = false;
//To change the random number only once
bool edited = true;
bool enemy = false;
int tries = 57;
//To contain the random generated value 
int Trial1 = 0;
int Trial2 = 0;
int Trial3 = 0;
int Trial4 = 0;
#endif