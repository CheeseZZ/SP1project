#include "game.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

ifstream mLayout;
string mLine;
char mArray[10][30] = { ' ' , };

void LoadLayout(int Map[10][30], GMAP mFloor)
{
	switch (mFloor)
	{
	case M_LEVEL1:
		mLayout.open("Map Layouts\\MapLayoutLv1.txt");
		break;
	case M_LEVEL2:
		mLayout.open("Map Layouts\\MapLayoutLv2.txt");
		break;
	case M_LEVEL3:
		mLayout.open("Map Layouts\\MapLayoutLv3.txt");
		break;
	}

	if (mLayout.is_open())
	{
		for (int y = 0; y < 10; y++)
		{
			getline(mLayout, mLine);
			mLine += '\n';

			for (int x = 0; x < 30; x++)
			{
				Map[y][x] = mLine[x] - 48;
				mArray[y][x] = mLine[x];
			}
		}
	}

	mLayout.close();
}