#ifndef _64_PUZZLE_H_
#define _64_PUZZLE_H_

bool mapFull = false;
#endif 
