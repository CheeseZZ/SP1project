#ifndef _RHYTHM_
#define _RHYTHM_
double  g_dBounceTime2;
bool good = false;
bool perfect = false;
bool cool = false;
bool miss = false;
int combo = 0;
int point4 = 0;
int x = 0;
#endif