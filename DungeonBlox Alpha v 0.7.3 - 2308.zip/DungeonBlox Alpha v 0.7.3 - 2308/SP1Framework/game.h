#ifndef _GAME_H
#define _GAME_H

#include "Framework\timer.h"
#include <string>
extern CStopWatch g_swTimer;
extern bool g_bQuitGame;


// Enumeration to store the control keys that your game will have
enum EKEYS
{
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    K_SPACE,
	K_F1,
	K_INT,
	K_ONE,
	K_TWO,
	K_THREE,
	K_FOUR,
    K_COUNT
};

// Enumeration for the different screen states
enum EGAMESTATES
{
    S_SPLASHSCREEN,
	S_MENU,
	S_SUBMENU,
    S_GAME,
    S_COUNT,
	S_PAUSE,
	S_SHOP,
	S_PUZZLE,
	S_BOSS,
	S_CHEST,
	S_NEXTLEVEL,
	S_ENDGAME,
	S_PUZZLE_PRACTICE,
	S_TESTING
};

// Enumeration for different Menu choices
enum EMENU
{
	M_NEW,
	M_PRACTICE
};

// Enumeration for different levels
enum GMAP
{
	M_LEVEL1,
	M_LEVEL2,
	M_LEVEL3
};

// Enumeration for different Puzzles
enum GPUZZLES
{	
	P_EMPTY,
	P_TRIAL_N_ERROR,
	P_64,
	P_RED_LIGHT_GREEN_LIGHT,
	P_RIDDLES
};

enum P_RIDDLER {
	R_QUESTION1,
	R_QUESTION2,
	R_QUESTION3,
	R_QUESTION4,
	R_QUESTION5,
	R_QUESTION6,
	R_FAIL,
	R_PASS
};
// Enumeration for Shop Items
enum items
{
	Flash,
	Heart,
	Present,
	Battery,
	Compass,
	Radar,
	Trap,
	Exit
};
// struct for the game character
struct SGameChar
{
    COORD m_cLocation;
    bool  m_bActive;
};
struct moveChar
{
	COORD m_cLocation2;
	bool m_bActive2;
};
struct Move4Char
{
	COORD m_cLocation4;
	bool m_bActive4;
};
struct Enemy4Char
{
	COORD m_cLocation5;
	bool m_bActive5;
};
struct EnemyVariables {
	COORD coor;
	int aEmptytiles[3][3] = { 0, };
	bool vacantTiles = false;
};


void init        ( void );      // initialize your variables, allocate memory, etc
void getInput    ( void );      // get input from player
void update      ( double dt ); // update the game and the state of the game
void render      ( void );      // renders the current state of the game to the console
void shutdown    ( void );      // do clean up, free memory

void splashScreenWait();						  // waits for time to pass in splash screen
void gameplay();								  // gameplay logic
void moveCharacter(int CurrentMap[10][30]);       // moves the character, collision detection, physics, etc
void processUserInput();						  // checks if you should change states or do something else with the game, e.g. pause, exit
void clearScreen();								  // clears the current screen and draw from scratch 
void renderSplashScreen();						  // renders the splash screen
void renderGame();								  // renders the game stuff
void renderMap(int CurrentMap[10][30]);           // renders the map to the buffer first
void renderCharacter();							  // renders the character into the buffer
void renderPauseScreen();						  // renders the pause screen
void renderMenu();								  // renders the pre-game Menu
void renderstats();								  // renders player statistics
void renderFramerate();							  // renders debug information, frame rate, elapsed time, etc
void renderToScreen();							  // dump the contents of the buffer to the screen, one frame worth of game
void saveFile();					           	// saves game into savefile
void loadFile();								  // loads savefile into game.
void chestRand();								  // Randomizes chest output
void chestRender();								  // Renders chest opening screen
void enemyAI(int CurrentMap[10][30]);			  // function to allow enemy movement
//
void renderPracticeScreen();
void puzzlePractice();

// Level Buffers
void nextLevelWait();
void renderNextLevel();

//Shop and Inventory
void updateShop();								//Update Shop
void renderShop();								//Render Shop
void renderInventory();	//render the inventory and items you have
void updateInventory();    //Updates contents of Inventory and monitor item usage


// Puzzles functions 
void puzzleRandomize();		// Randomizes puzzles

// Trial and error puzzle
void movepuzzle0();
void movePuzzle0();
void puzzle0();				//renders the Trial and error puzzle
void PuzzleT1(int CurrentMap[10][30]);			//renders the Trial and error puzzle difficulty 1
void PuzzleT2();			//renders the Trial and error puzzle difficulty 2
void PuzzleT3();			//renders the Trial and error puzzle difficulty 3

// 64 (2048-style) puzzle
int Puzzle64(int keyPressed, int PuzzleMap[4][4]);			// main logic function for puzzle 64
void renderPuzzle1();					// Renders puzzle to screen
void updatePuzzle(int keyPressed, int PuzzleMap[4][4]);		// updates tile coordinates 
void randomTileGenerator(bool newGame, int PuzzleMap[4][4]); // generates new tiles
void puzzle1Move(int CurrentMap[10][30]);						// detects key presses and updates puzzle
void Puzzle1Reset();					// Resets puzzle

// Riddler (BOSS) puzzle
void renderiddles();
void moveriddles();

#endif // _GAME_H