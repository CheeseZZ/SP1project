#ifndef _TRIAL_AND_ERROR_
#define _TRIAL_AND_ERROR_
// Puzzle 0 Variables //////////////////////////////////////////////////
COORD player;
COORD trap;
COORD answer;
double g_dElapsedTime2;
int a = 48, b = 48, d = 48, e = 48, f = 48, g = 48;
bool checkingT = false;
bool a1 = false;//needed because the first one apparently get reseted
bool a2 = false;
bool a3 = false;
bool a4 = false;
bool a5 = false;
bool a6 = false;
bool a7 = false;
bool pc1 = false;
bool pc2 = false;
bool pc3 = false;
bool pc4 = false;
bool pc5 = false;
bool pc6 = false;
bool edited = true;
bool enemy = false;
int tries = 57;
int Trial1 = 0;
int Trial2 = 0;
int Trial3 = 0;
int Trial4 = 0;
int Trial5 = 0;
int Trial6 = 0;
int difficulty = 0;
#endif