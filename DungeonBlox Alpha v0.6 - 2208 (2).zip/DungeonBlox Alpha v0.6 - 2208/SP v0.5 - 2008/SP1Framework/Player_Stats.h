#ifndef _PLAYER_STATS_
#define _PLAYER_STATS_

int options;
struct Inventory {
	bool lamp = false;
	bool trigger = false;
	int present = 0;
	int trap = 0;
	int clover = 0;
	int hourglass = 0;
};
struct Inventory Inv;
struct Player {
	int health = 3;
	int money = 5;
	struct Inventory Inv;
};
#endif // !_PLAYER_STATS_