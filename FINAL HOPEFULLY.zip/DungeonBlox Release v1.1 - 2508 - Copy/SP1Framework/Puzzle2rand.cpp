#include <ctime>
#include <iostream>
#include "game.h"

using namespace std;

int RLGLpuzzleID = 10;

int RLGL_ID(int floors, int random)
{
	switch (floors)
	{
	case M_LEVEL1:
		RLGLpuzzleID *= 1;
		break;
	case M_LEVEL2:
		RLGLpuzzleID *= 2;
		break;
	case M_LEVEL3:
		RLGLpuzzleID *= 3;
		break;
	}
	RLGLpuzzleID += random;

	return RLGLpuzzleID;
}

