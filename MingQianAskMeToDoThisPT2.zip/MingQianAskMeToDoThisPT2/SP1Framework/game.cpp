// This is the main file for the game logic and function
//
//
#include "game.h"
#include "Framework\console.h"
#include "levels.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
double  g_dElapsedTime;
double  g_dDeltaTime;
bool    g_abKeyPressed[K_COUNT];
bool    g_abKeyPressed1[K_COUNT];
using namespace std;
COORD player;
COORD answer;
//new
int a = 48, b = 48, d = 48, e = 48;
bool p = false;
bool a1 = false;//needed cause the first one apparently get reseted
bool a2 = false;
bool a3 = false;
bool a4 = false;
bool a5 = false;
bool pc1 = false;
bool pc2 = false;
bool pc3 = false;
bool pc4 = false;
bool edited = true;
bool enemy = false;
int tries = 10;
int health = 3;
int money = 10;
int Trial1 = 0;
int Trial2 = 0;
int Trial3 = 0;
int Trial4 = 0;
// Game specific variables here
SGameChar   g_sChar;
moveChar g_pChar;
moveRid g_rChar;
moveShop g_shChar;
EGAMESTATES g_eGameState = S_SPLASHSCREEN;
EMENU		g_eMenuState = S_NEW;
double  g_dBounceTime; // this is to prevent key bouncing, so we won't trigger keypresses more than once
// Console object
Console g_Console(90, 35, "SP1 Framework");

//--------------------------------------------------------------
// Purpose  : Initialisation function
//            Initialize variables, allocate memory, load data from file, etc. 
//            This is called once before entering into your main loop
// Input    : void
// Output   : void
//--------------------------------------------------------------
void init( void )
{
    // Set precision for floating point output
    g_dElapsedTime = 0.0;
    g_dBounceTime = 0.0;

    // sets the initial state for the game
    g_eGameState = S_SPLASHSCREEN;

    g_sChar.m_cLocation.X = 2;
    g_sChar.m_cLocation.Y = 1;
    g_sChar.m_bActive = true;
	g_pChar.m_cLocation2.X = 37;
	g_pChar.m_cLocation2.Y = 12;
	g_pChar.m_bActive2 = true;
    // sets the width, height and the font name to use in the console
    g_Console.setConsoleFont(0, 16, L"Consolas");
}

//--------------------------------------------------------------
// Purpose  : Reset before exiting the program
//            Do your clean up of memory here
//            This is called once just before the game exits
// Input    : Void
// Output   : void
//--------------------------------------------------------------
void shutdown( void )
{
    // Reset to white text on black background
    colour(FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED);

    g_Console.clearBuffer();
}

//--------------------------------------------------------------
// Purpose  : Getting all the key press states
//            This function checks if any key had been pressed since the last time we checked
//            If a key is pressed, the value for that particular key will be true
//
//            Add more keys to the enum in game.h if you need to detect more keys
//            To get other VK key defines, right click on the VK define (e.g. VK_UP) and choose "Go To Definition" 
//            For Alphanumeric keys, the values are their ascii values (uppercase).
// Input    : Void
// Output   : void
//--------------------------------------------------------------
void getInput( void )
{    
    g_abKeyPressed[K_UP]     = isKeyPressed(VK_UP);
    g_abKeyPressed[K_DOWN]   = isKeyPressed(VK_DOWN);
    g_abKeyPressed[K_LEFT]   = isKeyPressed(VK_LEFT);
    g_abKeyPressed[K_RIGHT]  = isKeyPressed(VK_RIGHT);
    g_abKeyPressed[K_SPACE]  = isKeyPressed(VK_SPACE);
    g_abKeyPressed[K_ESCAPE] = isKeyPressed(VK_ESCAPE);
	g_abKeyPressed[K_F1]    = isKeyPressed(VK_F1);
	g_abKeyPressed[K_Int] = isKeyPressed('E');
}

//--------------------------------------------------------------
// Purpose  : Update function
//            This is the update function
//            double dt - This is the amount of time in seconds since the previous call was made
//
//            Game logic should be done here.
//            Such as collision checks, determining the position of your game characters, status updates, etc
//            If there are any calls to write to the console here, then you are doing it wrong.
//
//            If your game has multiple states, you should determine the current state, and call the relevant function here.
//
// Input    : dt = deltatime
// Output   : void
//--------------------------------------------------------------
void update(double dt)
{
    // get the delta time
    g_dElapsedTime += dt;
    g_dDeltaTime = dt;

    switch (g_eGameState)
    {
        case S_SPLASHSCREEN : splashScreenWait(); // game logic for the splash screen
            break;
		case S_MENU: processUserInput(); // game logic for menu screen
			break;
        case S_GAME: gameplay(); // gameplay logic when we are in the game
            break;
		case S_PAUSE: processUserInput(); // game logic for pause screen
			break;
		case S_puzzle1:gameplay();
			break;
		case S_riddler: renderiddles();
			break;
		case S_SHOP: renderShop();
			break;
		case S_DEATH:processUserInput();
			break;

    }
}
//--------------------------------------------------------------
// Purpose  : Render function is to update the console screen
//            At this point, you should know exactly what to draw onto the screen.
//            Just draw it!
//            To get an idea of the values for colours, look at console.h and the URL listed there
// Input    : void
// Output   : void
//--------------------------------------------------------------
void render()
{
    clearScreen();      // clears the current screen and draw from scratch 
    switch (g_eGameState)
    {
        case S_SPLASHSCREEN: renderSplashScreen();
            break;
		case S_MENU: renderMenu();
			break;
        case S_GAME: renderGame();
            break;
		case S_PAUSE: renderPauseScreen();
			break;
		case S_puzzle1:puzzle1();
			break;
		case S_riddler: renderiddles();
			break;
		case S_SHOP: renderShop();
			break;
		case S_DEATH:gameover();
			break;
    }
    renderFramerate();  // renders debug information, frame rate, elapsed time, etc
    renderToScreen();   // dump the contents of the buffer to the screen, one frame worth of game
}

void splashScreenWait()    // waits for time to pass in splash screen
{
    if (g_dElapsedTime > 3.0) // wait for 3 seconds to switch to game mode, else do nothing
        g_eGameState = S_MENU;
}

void gameplay()            // gameplay logic
{
    processUserInput(); // checks if you should change states or do something else with the game, e.g. pause, exit
    moveCharacter();    // moves the character, collision detection, physics, etc
                        // sound can be played here too.
	movePuzzle();
}

void moveCharacter()
{
	bool bSomethingHappened = false;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	// Updating the location of the character based on the key press
	// providing a beep sound whenver we shift the character
	if (g_eGameState == S_GAME)
	{
		if (g_abKeyPressed[K_UP] && aLevel1[player.Y - 1][player.X] == 0 && player.Y > 0)
		{
			//Beep(1440, 30);
			g_sChar.m_cLocation.Y -= 2;
			bSomethingHappened = true;

		}
		if (g_abKeyPressed[K_LEFT] && aLevel1[player.Y][player.X - 1] == 0 && player.X > 0 && !g_abKeyPressed[K_DOWN] && !g_abKeyPressed[K_UP])
		{
			//Beep(1440, 30);
			g_sChar.m_cLocation.X -= 2;
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_DOWN] && aLevel1[player.Y + 1][player.X] == 0 && player.Y < 9)
		{
			//Beep(1440, 30);
			g_sChar.m_cLocation.Y += 2;
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_RIGHT] && aLevel1[player.Y][player.X + 1] == 0 && player.X < 29 && !g_abKeyPressed[K_DOWN] && !g_abKeyPressed[K_UP])
		{
			//Beep(1440, 30);
			g_sChar.m_cLocation.X += 2;
			bSomethingHappened = true;
		}

		if (g_abKeyPressed[K_Int] && ((aLevel1[player.Y + 1][player.X] == 3 && player.Y < 9) ||( aLevel1[player.Y - 1][player.X] == 3 && player.Y > 0 )|| (aLevel1[player.Y][player.X + 1] == 3 && player.X < 29) || (aLevel1[player.Y][player.X - 1] == 3 && player.X > 0)))
		{
			g_eGameState = S_SHOP;
		}
		if ((aLevel1[player.Y + 1][player.X] == 2 && player.Y<9)|| (aLevel1[player.Y - 1][player.X] == 2&&player.Y>0) || (aLevel1[player.Y][player.X + 1] == 2 && player.X<29)|| (aLevel1[player.Y][player.X - 1] == 2&&player.X>0))
		{
			if (g_abKeyPressed[K_Int] || enemy==true)
			{
				g_eGameState = S_puzzle1;
				enemy = true;
			}
		}
	}
	if (g_abKeyPressed[K_SPACE] && g_eGameState == S_GAME)
	{
		g_sChar.m_bActive = !g_sChar.m_bActive;
		bSomethingHappened = true;
	}
	if (health == 0)
	{
		g_eGameState = S_DEATH;
	}
	if (bSomethingHappened)
	{
		// set the bounce time to some time in the future to prevent accidental triggers
		g_dBounceTime = g_dElapsedTime + 0.125; // 125ms should be enough
	}
}
void movePuzzle()
{
	bool bSomethingHappened = false;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	if (g_eGameState == S_puzzle1)
	{
		if (g_abKeyPressed[K_RIGHT] && g_pChar.m_cLocation2.X < 43)
		{
			g_pChar.m_cLocation2.X += 2;
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_LEFT] && g_pChar.m_cLocation2.X > 37)
		{
			g_pChar.m_cLocation2.X -= 2;
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_UP])
		{
			if (g_pChar.m_cLocation2.X == 37 && a < '9')
			{
				a++;
			}
			if (g_pChar.m_cLocation2.X == 39 && b < '9')
			{
				b++;
			}
			if (g_pChar.m_cLocation2.X == 41 && d < '9')
			{
				d++;
			}
			if (g_pChar.m_cLocation2.X == 43 && e < '9')
			{
				e++;
			}
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_DOWN])
		{
			if (g_pChar.m_cLocation2.X == 37 && a > '0')
			{
				a--;
			}
			if (g_pChar.m_cLocation2.X == 39 && b > '0')
			{
				b--;
			}
			if (g_pChar.m_cLocation2.X == 41 && d > '0')
			{
				d--;
			}
			if (g_pChar.m_cLocation2.X == 43 && e > '0')
			{
				e--;
			}
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_SPACE])
		{
			p = true;
			bSomethingHappened = true;
			tries--;
			pc1 = false; pc2 = false; pc3 = false; pc4 = false;
		}
		if (bSomethingHappened)
			{
				// set the bounce time to some time in the future to prevent accidental triggers
				g_dBounceTime = g_dElapsedTime + 0.125; // 125ms should be enough
			}
	}
}
void processUserInput()
{
	bool bSomethingHappened = false;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	// Changes menu state accordingly
	if (g_abKeyPressed[K_DOWN] && g_eGameState == S_MENU) // press down for continue game state
		g_eMenuState = S_CONTINUE;
	if (g_abKeyPressed[K_UP] && g_eGameState == S_MENU) // press up for New game state
		g_eMenuState = S_NEW;
	// Load or start new game according to state
	if (g_abKeyPressed[K_SPACE]) {
		switch (g_eMenuState) {
		case S_NEW: g_eGameState = S_GAME;
			break;
		case S_CONTINUE: loadFile();
			g_eGameState = S_GAME;
			break;
		}
	}
	// pauses/unpauses the game if player hits the F1 key
	if (g_abKeyPressed[K_F1]&& g_eGameState == S_PAUSE)
		g_eGameState = S_GAME;
	else if (g_abKeyPressed[K_F1])
		g_eGameState = S_PAUSE;
    // quits the game if player hits the escape key
    else if (g_abKeyPressed[K_ESCAPE])
        g_bQuitGame = true;
	
	if (bSomethingHappened)
	{
		// set the bounce time to some time in the future to prevent accidental triggers
		g_dBounceTime = g_dElapsedTime + 0.25; // 250ms should be enough
	}
	//exit shop if player hits the E key
	if (g_abKeyPressed[K_Int] && g_eGameState == S_SHOP)
	{
			g_eGameState = S_GAME;
	}
	//What happen at death
	if (g_abKeyPressed[K_Int] && g_eGameState == S_DEATH)
	{
		g_eGameState=S_GAME;
		health = 3;
	}
	if (g_abKeyPressed[K_ESCAPE]&&g_eGameState==S_DEATH)
			g_bQuitGame = true;
	
}

void clearScreen()
{
    // Clears the buffer with this colour attribute
    g_Console.clearBuffer(0x1F);
}

void renderSplashScreen()  // renders the splash screen
{
    COORD c = g_Console.getConsoleSize();
    c.Y /= 3;
    c.X = c.X / 2 - 9;
    g_Console.writeToBuffer(c, "A game in 3 seconds", 0x03);
    c.Y += 1;
    c.X = g_Console.getConsoleSize().X / 2 - 20;
    g_Console.writeToBuffer(c, "Press <Space> to change character colour", 0x09);
    c.Y += 1;
    c.X = g_Console.getConsoleSize().X / 2 - 9;
    g_Console.writeToBuffer(c, "Press 'Esc' to quit", 0x09);
}

void renderGame()
{
	renderStats();		// renders statistics to screen
    renderMap();        // renders the map to the buffer first
    renderCharacter();  // renders the character into the buffer
}

void renderMap()
{
    // Set up sample colours, and output shadings
    const WORD colors[] = {
        0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
        0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
    };
    COORD c;
	player.X = (g_sChar.m_cLocation.X / 2) - 1;
	player.Y = (g_sChar.m_cLocation.Y / 2);
	c.Y = 1;
	// Render frames for game, inventory, etc.
	for (int y = 0; y < 10; y++, c.Y+= 2) {
		c.X = 2;
		for (int x = 0; x < 30; x++, c.X+= 2) {
			if (((x == player.X) && (y == player.Y)) || ((x == player.X) && (y == player.Y - 1 || y == player.Y + 1)) || ((y == player.Y) && (x == player.X - 1 || x == player.X + 1)) || aLevelProgress[y][x]) {
				aLevelProgress[y][x] = 1;
				// for loop to scale map size by 2
				for (int i = 0; i < 4; i++) {
					// switch to ensure smooth scaling
					switch (i) {
					case 0:
						break;
					case 1:
						c.X++;
						break;
					case 2:
						c.Y++;
						break;
					case 3:
						c.X--;
						break;
					}
					switch (aLevel1[y][x]) {
					case 0: // empty tile
						g_Console.writeToBuffer(c, " ", 0xFF);
						break;
					case 1: // wall
						g_Console.writeToBuffer(c, " ", 0x00);
						break;
					case 2: // enemy
						g_Console.writeToBuffer(c, " ", 0xE0);
						break;
					case 3: // chests
						g_Console.writeToBuffer(c, " ", 0xAA);
						break;
					case 4: // shop
						g_Console.writeToBuffer(c, " ", 0xBB);
						break;
					case 5: // final
						g_Console.writeToBuffer(c, " ", 0xD0);
						break;
					default:
						g_Console.writeToBuffer(c, " ", 0x00);
						break;
					}
				}
			}
			else
				continue;
			c.Y--;
		}
	}
}

void renderCharacter()
{
	// value of character
	char charImage = 2;
	// Draw the location of the character
	WORD charColor = 0xF6;
	if (g_sChar.m_bActive)
	{
		charColor = 0xFF;
	}

	// loop to scale the character size by 2
	for (int i = 0; i < 4; i++) {
		switch (i) {
		case 0:
			break;
		case 1:
			g_sChar.m_cLocation.X++;
			charImage = 191;
			break;
		case 2:
			g_sChar.m_cLocation.Y++;
			charImage = 217;
			break;
		case 3:
			g_sChar.m_cLocation.X--;
			charImage = 192;
			break;
		}
		g_Console.writeToBuffer(g_sChar.m_cLocation, charImage, charColor);
	}
	g_sChar.m_cLocation.Y--;
}
void move()
{
		WORD charColor = 0x0C;
	if (g_sChar.m_bActive)
	{
		charColor = 0x0A;
	}
	if(g_pChar.m_cLocation2.X==37)
	g_Console.writeToBuffer(g_pChar.m_cLocation2, a, charColor);
	if (g_pChar.m_cLocation2.X == 39)
	g_Console.writeToBuffer(g_pChar.m_cLocation2, b, charColor);
	if (g_pChar.m_cLocation2.X == 41)
	g_Console.writeToBuffer(g_pChar.m_cLocation2, d, charColor);
	if (g_pChar.m_cLocation2.X == 43)
	g_Console.writeToBuffer(g_pChar.m_cLocation2, e, charColor);
}

void renderFramerate()
{
    COORD c;
    // displays the framerate
    std::ostringstream ss;
    ss << std::fixed << std::setprecision(3);
    ss << 1.0 / g_dDeltaTime << "fps";
    c.X = g_Console.getConsoleSize().X - 9;
    c.Y = 0;
    g_Console.writeToBuffer(c, ss.str());

    // displays the elapsed time
    ss.str("");
    ss << g_dElapsedTime << "secs";
    c.X = 0;
    c.Y = 0;
    g_Console.writeToBuffer(c, ss.str(), 0x59);
}
void renderToScreen()
{
    // Writes the buffer to the console, hence you will see what you have written
    g_Console.flushBufferToConsole();
}
void renderPauseScreen() // Renders pause screen
{
	COORD c = g_Console.getConsoleSize();
	c.Y = 4;
	c.X = 6;
	g_Console.writeToBuffer(c, "Paused", 0x01);
	c.Y++;
	c.X = 4;
	g_Console.writeToBuffer(c, "Press F1 to contiue", 0x03);
}
void renderMenu() // Renders Menu
{
	COORD c = g_Console.getConsoleSize();
	c.Y = 4;
	c.X = 6;
	g_Console.writeToBuffer(c, "Welcome to ", 0x0A);
	c.Y += 2;
	g_Console.writeToBuffer(c, "New Game", 0x0A);
	c.Y++;
	g_Console.writeToBuffer(c, "Continue", 0x0A);
	c.Y = 6 + g_eMenuState;
	c.X = 5;
	g_Console.writeToBuffer(c, ">", 0x0A);
}
void renderStats()
{	//display health
	COORD c;
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);
	ss.str("");
	ss << "Life: ";
	for (int i = 0;i<health;i++)
	{
		ss << (char)3;
	}
	c.X = 2;
	c.Y = 22;
	g_Console.writeToBuffer(c, ss.str(), 0x59);

	//display cash
	int money = 5;
	ss.str("");
	ss << "Cash: " << money;
	c.X = 2;
	c.Y = 23;
	g_Console.writeToBuffer(c, ss.str(), 0x59);

}
void renderShop()
{
	updateShop();
	COORD c;
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);
	const WORD colors[] =
	{
		0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
		0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
	};
	enum items
	{
		Flash,
		Heart,
		Present,
		Battery,
		Compass,
		Trap,
		Exit,
		Count,
	};
	c.Y = 5; c.X = 30;
	g_Console.writeToBuffer(c, "Merchant Tom", colors[1]);
	c.Y = 6;
	g_Console.writeToBuffer(c, "Have you seen my wife Jasmine?");
	c.Y = 7;
	g_Console.writeToBuffer(c, "She ran away a few days ago");
	c.Y = 10 + Flash;
	g_Console.writeToBuffer(c, "Flashlight :$10", colors[4]);
	c.Y = 10 + Heart;
	g_Console.writeToBuffer(c, "Extra hearts :$10", colors[4]);
	c.Y = 10 + Present;
	g_Console.writeToBuffer(c, "Present :$5", colors[4]);
	c.Y = 10 + Battery;
	g_Console.writeToBuffer(c, "Batteries :$5", colors[4]);
	c.Y = 10 + Compass;
	g_Console.writeToBuffer(c, "Compass $5", colors[4]);
	c.Y = 10 + Trap;
	g_Console.writeToBuffer(c, "Traps $5", colors[4]);
	c.Y = 10 + Exit;
	g_Console.writeToBuffer(c, "Exit shop", colors[4]);
}

void updateShop()
{
	string Inventory;
	int options;
	struct item
	{
		string name[8] = { "  Flashlight  ","  Thyme  ","  Hint  ", "  Heart  ", "  Present  ", "  Battery ", "  Compass  ", "  Trap  " };
		int price[8] = { 10,7,5,10,15,12,15 };
		int numbers[8];
	};
	struct item buy;

	enum items
	{
		Flash,
		Thyme,
		Hint,
		Heart,
		Present,
		Compass,
		Trap,
		Exit,
		Count
	};
	bool bSomethingHappened = false;
	if (g_eGameState == S_SHOP)
	{
		WORD charColor = 0x0C;
		if (g_shChar.m_bActive4)
		{
			charColor = 0x0A;
		}
		g_shChar.m_cLocation4.X = 29;
		if (g_shChar.m_cLocation4.Y < 10)
		{
			g_shChar.m_cLocation4.Y = 16;
		}
		if (g_shChar.m_cLocation4.Y > 16)
		{
			g_shChar.m_cLocation4.Y = 10;
		}
		g_Console.writeToBuffer(g_shChar.m_cLocation4, ">", charColor);
		if (g_dBounceTime > g_dElapsedTime)
			return;
		if (g_abKeyPressed[K_UP] && g_shChar.m_cLocation4.Y > 0)
		{
			//Beep(1440, 30);
			g_shChar.m_cLocation4.Y--;
			bSomethingHappened = true;
		}

		if (g_abKeyPressed[K_DOWN] && g_shChar.m_cLocation4.Y < g_Console.getConsoleSize().Y - 1)
		{
			//Beep(1440, 30);
			g_shChar.m_cLocation4.Y++;
			bSomethingHappened = true;
		}

		if (g_abKeyPressed[K_SPACE])
		{

			options = g_shChar.m_cLocation4.Y - 10;

			g_shChar.m_bActive4 = !g_shChar.m_bActive4;
			bSomethingHappened = true;
			if (options == Flash && money > 10)
			{
				money -= 5;
				Inventory += buy.name[Flash];
				buy.numbers[Flash] = +1;
				options = 0;
			}
			if (options == Heart && money > 5)
			{
				health += 1;
				Inventory += buy.name[Heart];
				money -= 5;
				options = 0;
			}
			if (options == Present && money > 5)
			{
				Inventory += buy.name[Present];
				money -= 5;
				options = 0;
			}
			if (options == Thyme && money > 5)
			{
				Inventory += buy.name[Thyme];
				money -= 5;
				options = 0;
			}
			if (options == Compass && money > 5)
			{
				Inventory += buy.name[Compass];
				money -= 5;
				options = 0;
			}
			if (options == Hint && money > 5)
			{
				Inventory += buy.name[Hint];
				money -= 5;
				options = 0;
			}
			if (options == Trap && money > 5)
			{
				Inventory += buy.name[Trap];
				money -= 5;
				options = 0;
			}
			if (options == Exit)
			{
				g_eGameState = S_GAME;
			}
		}

		if (bSomethingHappened)
		{
			// set the bounce time to some time in the future to prevent accidental triggers
			g_dBounceTime = g_dElapsedTime + 0.125; // 125ms should be enough
		}
	}
}


int Qns = 0;

void moveriddles()
{

	bool bSomethingHappened = false;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	if (g_eGameState == S_riddler)
	{
		WORD charColor = 0x0C;
		if (g_sChar.m_bActive)
		{
			charColor = 0x0A;
		}

		g_rChar.m_cLocation3.X = 9;
		if (g_rChar.m_cLocation3.Y < 10)
		{
			g_rChar.m_cLocation3.Y = 13;
		}
		if (g_rChar.m_cLocation3.Y > 13)
		{
			g_rChar.m_cLocation3.Y = 10;
		}
		g_Console.writeToBuffer(g_rChar.m_cLocation3, ">", charColor);
		if (g_abKeyPressed[K_UP] && g_rChar.m_cLocation3.Y > 0)
		{
			//Beep(1440, 30);
			g_rChar.m_cLocation3.Y--;
			bSomethingHappened = true;
		}

		if (g_abKeyPressed[K_DOWN] && g_rChar.m_cLocation3.Y < g_Console.getConsoleSize().Y - 1)
		{
			//Beep(1440, 30);
			g_rChar.m_cLocation3.Y++;
			bSomethingHappened = true;
		}
		if (g_abKeyPressed[K_SPACE] && Qns == 0 && !bSomethingHappened)
		{
			bSomethingHappened = true;
			if (g_rChar.m_cLocation3.Y == 10) { Qns = 1; }
			else { Qns = 9; }
		}
		if (g_abKeyPressed[K_SPACE] && Qns == 1 && !bSomethingHappened)
		{
			bSomethingHappened = true;
			if (g_rChar.m_cLocation3.Y == 13) { Qns = 2; }
			else { Qns = 9; }
		}
		if (g_abKeyPressed[K_SPACE] && Qns == 2 && !bSomethingHappened)
		{
			bSomethingHappened = true;
			if (g_rChar.m_cLocation3.Y == 13) { Qns = 3; }
			else { Qns = 9; }

		}
		if (g_abKeyPressed[K_SPACE] && Qns == 3 && !bSomethingHappened)
		{
			bSomethingHappened = true;
			if (g_rChar.m_cLocation3.Y == 12) { Qns = 4; }
			else { Qns = 9; }

		}
		if (g_abKeyPressed[K_SPACE] && Qns == 4 && !bSomethingHappened)
		{
			bSomethingHappened = true;
			if (g_rChar.m_cLocation3.Y == 11) { Qns = 5; }
			else { Qns = 9; }
		}
		if (g_abKeyPressed[K_SPACE] && Qns == 5 && !bSomethingHappened)
		{
			bSomethingHappened = true;
			if (g_rChar.m_cLocation3.Y == 13) { Qns = 6; }
			else { Qns = 9; }
		}
		if (g_abKeyPressed[K_SPACE] && Qns == 6 && !bSomethingHappened)
		{
			bSomethingHappened = true;
			g_eGameState = S_GAME;
			money += 10;

		}

		if (g_abKeyPressed[K_SPACE] && Qns == 9 && !bSomethingHappened)
		{
			bSomethingHappened = true;
			g_eGameState = S_GAME;
			health -= 1;

		}
		if (bSomethingHappened)
		{
			// set the bounce time to some time in the future to prevent accidental triggers
			g_dBounceTime = g_dElapsedTime + 0.2; // 125ms should be enough
		}
	}

}

void puzzle()
{
	COORD c = g_Console.getConsoleSize();
	c.Y = 10;
	c.X = 25;
	g_Console.writeToBuffer(c, "Find the correct number and order", 0x03);
	c.Y = 12;
	c.X = 37;
	g_Console.writeToBuffer(c, a, 0x03);
	c.X = 39;
	g_Console.writeToBuffer(c, b, 0x03);
	c.X = 41;
	g_Console.writeToBuffer(c, d, 0x03);
	c.X = 43;
	g_Console.writeToBuffer(c, e, 0x03);
}
void puzzle1()
{
	if (edited)
	{
		srand(time(NULL));
		Trial1 = rand() % 10 + 48;
		Trial2 = rand() % 10 + 48;
		Trial3 = rand() % 10 + 48;
		Trial4 = rand() % 10 + 48;
		edited = false;
	}
	COORD c = g_Console.getConsoleSize();
	puzzle();
	move();
	if (p)
	{
		if (a == Trial1)
		{
			a5 = true;
		}
		if (b == Trial2)
		{
			a2 = true;
		}
		if (d == Trial3)
		{
			a3 = true;
		}
		if (e == Trial4)
		{
			a4 = true;
		}
	}
	c.Y = 14;
	c.X = 25;
	g_Console.writeToBuffer(c,"Correct", 0x03);
	if (a5)
	{
		c.X = 37;
		g_Console.writeToBuffer(c, Trial1, 0x03);
	}
	if (a2)
	{
		c.X = 39;
		g_Console.writeToBuffer(c, Trial2, 0x03);
	}
	if (a3)
	{
		c.X = 41;
		g_Console.writeToBuffer(c, Trial3, 0x03);
	}
	if (a4)
	{
		c.X = 43;
		g_Console.writeToBuffer(c, Trial4, 0x03);
	}
	if (a==Trial1 && b==Trial2 && d== Trial3 && e== Trial4 && g_abKeyPressed[K_SPACE])
	{
		g_eGameState = S_GAME;
		if (aLevel1[player.Y + 1][player.X] == 2)
		{
			aLevel1[player.Y + 1][player.X] = 0;
		}
		else if (aLevel1[player.Y - 1][player.X] == 2)
		{
			aLevel1[player.Y - 1][player.X] = 0;
		}
		else if (aLevel1[player.Y][player.X + 1] == 2)
		{
			aLevel1[player.Y][player.X + 1] = 0;
		}
		else if (aLevel1[player.Y][player.X - 1] == 2)
		{
			aLevel1[player.Y][player.X - 1] = 0;
		}
		a5 = false; a2 = false; a3 = false; a4 = false;
		pc1 = false; pc2 = false; pc3 = false; pc4 = false;
		enemy = false; edited = true;
		tries = 10;
		a = 48; b = 48; d = 48; e = 48;
	}
	c.Y = 16;
	c.X = 16;
	g_Console.writeToBuffer(c, "Partially correct:", 0x03);
	if (p)
	{
		if (a == Trial2|| a == Trial3 || a== Trial4)
		{
			pc1 = true;
		}
		if (b == Trial1 ||b== Trial3 ||b== Trial4)
		{
			pc2 = true;
		}
		if (d == Trial1||d== Trial2||d== Trial4)
		{
			pc3 = true;
		}
		if (e== Trial1||e== Trial2||e == Trial3)
		{
			pc4 = true;
		}
		p = false;
	}
	if (pc1)
	{
		c.X = 37;
		g_Console.writeToBuffer(c,"/" , 0x03);
	}
	if (pc2)
	{
		c.X = 39;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	if (pc3)
	{
		c.X = 41;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	if (pc4)
	{
		c.X = 43;
		g_Console.writeToBuffer(c, "/", 0x03);
	}
	if (tries == 0)
	{
		g_eGameState = S_GAME;
		if (aLevel1[player.Y + 1][player.X] == 2 && aLevel1[player.Y - 1][player.X] == 0)
		{
			g_sChar.m_cLocation.Y -= 2;
		}
		if (aLevel1[player.Y - 1][player.X] == 2 && aLevel1[player.Y + 1][player.X] == 0)
		{
			g_sChar.m_cLocation.Y += 2;
		}
		if (aLevel1[player.Y][player.X + 1] == 2 && aLevel1[player.Y][player.X - 1] == 0)
		{
			g_sChar.m_cLocation.X -= 2;
		}
		if (aLevel1[player.Y][player.X - 1] == 2 && aLevel1[player.Y][player.X + 1] == 0)
		{
			g_sChar.m_cLocation.X += 2;
		}
		a5 = false; a2 = false; a3 = false; a4 = false;
		pc1 = false; pc2 = false; pc3 = false; pc4 = false;
		enemy = false; edited = true;
		tries = 10;
		a = 48; b = 48; d = 48; e = 48;
		health -= 1;
	}
}

void gameover()
{
	COORD c = g_Console.getConsoleSize();
	c.Y = 4;
	c.X = 6;
	g_Console.writeToBuffer(c, "This is the dead screen", 0x0A);
	c.Y += 2;
	g_Console.writeToBuffer(c, "You ran out of life", 0x0A);
	c.Y++;
	g_Console.writeToBuffer(c, "Wow even hell does not want you", 0x0A);
	c.Y++;
	g_Console.writeToBuffer(c, "Press 'E' to try again", 0x0A);
	c.Y++;
	g_Console.writeToBuffer(c, "Press 'ESC' to quit", 0x0A);
	c.Y++;
	g_Console.writeToBuffer(c, "Press 'F' for respect", 0x0A);
}
void renderiddles()
{

	moveriddles();
	COORD c;
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);
	const WORD colors[] =
	{
		0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
		0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
	};

	c.X = 10;

	if (Qns == 0)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "Riddler: If you answer my riddles correctly, you may pass", colors[1]);
		c.Y = 8;
		g_Console.writeToBuffer(c, "But if you get them wrong, be prepared to suffer, Ready? ", colors[1]);
		c.Y = 10;
		g_Console.writeToBuffer(c, "Yes", colors[2]);
		c.Y = 11;
		g_Console.writeToBuffer(c, "Maybe", colors[2]);
		c.Y = 12;
		g_Console.writeToBuffer(c, "No", colors[2]);
		c.Y = 13;
		g_Console.writeToBuffer(c, "Lol the Riddler", colors[2]);
	}

	if (Qns == 1)
	{

		c.Y = 7;
		g_Console.writeToBuffer(c, "I have a mouth but do not speek, I have a bed but do not sleep,");
		c.Y = 8;
		g_Console.writeToBuffer(c, "I run every where but go know were, what am I?");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a. Starfish");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b. Jellyfish");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c. Ocean");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d. River");

	}

	if (Qns == 2)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "I have a head and a tail, but no legs , what am I?");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a. A tadpole");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b. A snake");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c. A Salmon");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d. A coin");

	}


	if (Qns == 3)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "The more you take, the more you leave behind. what am I?");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a. Loans");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b. Children");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c. Footprints");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d. Investment");
	}

	if (Qns == 4)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "I am the beginning of the End, and the End of time and space");
		c.Y = 8;
		g_Console.writeToBuffer(c, "I am Essential to creation, and I surround every place.");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a. Dark matter");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b. The letter E");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c. Death");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d. Azatoth");

	}


	if (Qns == 5)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "I look like the Statue of Liberty, I look like surprised pikachu");
		c.Y = 9;
		g_Console.writeToBuffer(c, "And I like movies and math, Who am I?");
		c.Y = 10;
		g_Console.writeToBuffer(c, "a.Frederic Auguste Bartholdi");
		c.Y = 11;
		g_Console.writeToBuffer(c, "b.Carl Gauss");
		c.Y = 12;
		g_Console.writeToBuffer(c, "c.Serena Gomez");
		c.Y = 13;
		g_Console.writeToBuffer(c, "d.Mr Tang of Nanyang Poly");
	}
	if (Qns == 6)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "You solved my riddles?? But I am THE RIDDLER!");
		c.Y = 8;
		g_Console.writeToBuffer(c, "THIS IS IMPOSSIBLE!!!!!! I AM UNBEATABLE!!");
		c.Y = 10;
		g_Console.writeToBuffer(c, "Soka..");
		c.Y = 11;
		g_Console.writeToBuffer(c, "Hao..");
		c.Y = 12;
		g_Console.writeToBuffer(c, "Theek...");
		c.Y = 13;
		g_Console.writeToBuffer(c, "Ok...");
	}

	if (Qns == 9)
	{
		c.Y = 7;
		g_Console.writeToBuffer(c, "That is incorrect!! You take one damage from Riddler!");
	}


}